import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'accounts.dart';
import 'chat_screen.dart';
import 'config.dart';
import 'group_screens.dart';
import 'messaging.dart';
import 'profile_screen.dart';
import 'settings_screen.dart';
import 'widgets.dart';

int _ms(JsonDoc d) {
  final t = d.data()['last_time'];
  return t is Timestamp ? t.millisecondsSinceEpoch : DateTime.now().millisecondsSinceEpoch;
}

bool _matches(String q, String name, String username, String last) {
  final qq = q.replaceFirst(RegExp(r'^@+'), '');
  return name.toLowerCase().contains(q) || username.toLowerCase().contains(qq) || last.toLowerCase().contains(q);
}

class ChatsListScreen extends StatefulWidget {
  final Map<String, dynamic> me;
  const ChatsListScreen({super.key, required this.me});
  @override
  State<ChatsListScreen> createState() => _ChatsListScreenState();
}

class _ChatsListScreenState extends State<ChatsListScreen> with WidgetsBindingObserver {
  final _q = TextEditingController();
  String _query = '';
  int _tab = 0;
  Future<List<Map<String, dynamic>>>? _global;
  Timer? _presence;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _sub;
  final Map<String, int> _prevUnread = {};
  bool _firstSnap = true;
  int _totalUnread = 0;

  String get myTg => widget.me['tg_username'] as String;
  String get myName => (widget.me['display_name'] as String?) ?? '';

  Query<Map<String, dynamic>> _chatsQuery() => FirebaseFirestore.instance.collection('chats').where('users', arrayContains: myTg);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) ensureUsername(uid, myTg, widget.me['username'] as String?);
    AccountStore.add(currentSaved(widget.me));
    ensureEmberChannel(myTg, uname(widget.me));
    _sub = _chatsQuery().snapshots().listen(_onChats, onError: (_) {});
    _touchPresence();
    _presence = Timer.periodic(const Duration(seconds: 45), (_) => _touchPresence());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _presence?.cancel();
    _sub?.cancel();
    _q.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _touchPresence();
  }

  void _touchPresence() {
    final u = FirebaseAuth.instance.currentUser;
    if (u == null) return;
    FirebaseFirestore.instance.collection('users').doc(u.uid).update({'last_seen': FieldValue.serverTimestamp()}).catchError((_) {});
  }

  /// Считает непрочитанные и показывает баннер о новом сообщении (пока приложение открыто).
  void _onChats(QuerySnapshot<Map<String, dynamic>> s) {
    var total = 0;
    for (final d in s.docs) {
      final c = d.data();
      final un = (((c['unread'] as Map?)?[myTg]) as num?)?.toInt() ?? 0;
      total += un;
      final prev = _prevUnread[d.id] ?? 0;
      if (!_firstSnap && un > prev && ChatScreen.openChatId != d.id) _banner(d.id, c);
      _prevUnread[d.id] = un;
    }
    _firstSnap = false;
    if (mounted && total != _totalUnread) setState(() => _totalUnread = total);
  }

  void _banner(String chatId, Map<String, dynamic> c) {
    if (!mounted) return;
    final title = (c['title'] as String?) ?? 'Новое сообщение';
    final last = (c['last_msg'] as String?) ?? '';
    final sm = ScaffoldMessenger.of(context);
    sm.hideCurrentSnackBar();
    sm.showSnackBar(SnackBar(
      content: Text('$title: $last', maxLines: 2, overflow: TextOverflow.ellipsis),
      action: SnackBarAction(label: 'ОТКРЫТЬ', onPressed: () => _openChat(chatId)),
    ));
  }

  void _openChat(String chatId) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: chatId, myTg: myTg, myName: myName)));
  }

  void _onSearch(String v) {
    final t = v.trim();
    final c = cleanTg(t);
    setState(() {
      _query = t;
      _global = c.length >= 2 ? _runGlobal(c) : null;
    });
  }

  /// Глобальный поиск по реестру имён: люди и каналы.
  Future<List<Map<String, dynamic>>> _runGlobal(String q) async {
    final db = FirebaseFirestore.instance;
    final snap = await db
        .collection('usernames')
        .where(FieldPath.documentId, isGreaterThanOrEqualTo: q)
        .where(FieldPath.documentId, isLessThan: '$q\uf8ff')
        .limit(10)
        .get();
    final res = <Map<String, dynamic>>[];
    for (final d in snap.docs) {
      final data = d.data();
      final chatId = data['chat'] as String?;
      if (chatId != null) {
        final c = (await db.collection('chats').doc(chatId).get()).data();
        if (c == null) continue;
        res.add(<String, dynamic>{
          '_kind': 'channel',
          '_chat': chatId,
          'title': c['title'],
          'verified': c['verified'] == true,
          'username': d.id,
        });
        continue;
      }
      final tg = data['tg'] as String?;
      if (tg == null || tg == myTg) continue;
      final us = await db.collection('users').where('tg_username', isEqualTo: tg).get();
      final best = latestUserDoc(us.docs);
      res.add(<String, dynamic>{
        if (best != null) ...best.data(),
        'tg_username': tg,
        'username': d.id,
        '_uid': best?.id ?? '',
      });
    }
    return res;
  }

  void _resetSearch() {
    _q.clear();
    setState(() {
      _query = '';
      _global = null;
    });
  }

  Future<void> _openFound(Map<String, dynamic> u) async {
    if (u['_kind'] == 'channel') {
      _resetSearch();
      _openChat(u['_chat'] as String);
      return;
    }
    final t = u['tg_username'] as String;
    final db = FirebaseFirestore.instance;
    try {
      final mine = await db.collection('chats').where('users', arrayContains: myTg).get();
      String? chatId;
      for (final d in mine.docs) {
        final c = d.data();
        if (((c['type'] as String?) ?? 'private') == 'private' && ((c['users'] as List?) ?? []).contains(t)) {
          chatId = d.id;
          break;
        }
      }
      if (chatId == null) {
        final ids = [myTg, t]..sort();
        chatId = ids.join('__');
        await db.collection('chats').doc(chatId).set({'type': 'private', 'users': ids, 'last_time': FieldValue.serverTimestamp()});
      }
      if (!mounted) return;
      _resetSearch();
      _openChat(chatId);
    } catch (e) {
      if (mounted) snack(context, 'Ошибка: $e');
    }
  }

  void _onLong(String id, Map<String, dynamic> c, String name) {
    if (id == emberChatId) {
      snack(context, 'Канал Ember нельзя удалить или покинуть');
      return;
    }
    final type = (c['type'] as String?) ?? 'private';
    final admins = ((c['admins'] as List?) ?? []).cast<String>();
    final delete = type == 'private' || admins.contains(myTg);
    final title = delete ? 'Удалить чат?' : (type == 'channel' ? 'Отписаться от канала?' : 'Покинуть группу?');
    final text = delete ? 'Вся переписка «$name» будет удалена у всех. Продолжить?' : '«$name» пропадёт из вашего списка.';
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(text),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ОТМЕНА')),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              try {
                if (delete) {
                  await deleteChatCompletely(id, handle: c['username'] as String?);
                } else {
                  await FirebaseFirestore.instance.collection('chats').doc(id).update({'users': FieldValue.arrayRemove([myTg])});
                }
              } catch (e) {
                if (mounted) snack(context, 'Ошибка: $e');
              }
            },
            child: Text(delete ? 'УДАЛИТЬ' : 'ВЫЙТИ', style: const TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Widget _searchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
      child: TextField(
        controller: _q,
        onChanged: _onSearch,
        autocorrect: false,
        decoration: InputDecoration(
          hintText: 'Поиск',
          prefixIcon: const Icon(Icons.search),
          suffixIcon: _query.isEmpty ? null : IconButton(icon: const Icon(Icons.close), onPressed: _resetSearch),
          filled: true,
          fillColor: surfaceDark,
          contentPadding: EdgeInsets.zero,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
        ),
      ),
    );
  }

  Widget _chatsBody() {
    return Column(children: [
      _searchBar(),
      Expanded(
        child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: _chatsQuery().snapshots(),
          builder: (context, snap) {
            if (snap.hasError) return Center(child: Text('Ошибка: ${snap.error}'));
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final docs = snap.data!.docs.toList()
              ..sort((a, b) {
                final pa = a.data()['verified'] == true ? 1 : 0;
                final pb = b.data()['verified'] == true ? 1 : 0;
                if (pa != pb) return pb.compareTo(pa);
                return _ms(b).compareTo(_ms(a));
              });
            final q = _query.toLowerCase();
            final g = _global;
            return ListView(children: [
              for (final d in docs)
                _ChatTile(
                  key: ValueKey(d.id),
                  chatId: d.id,
                  chat: d.data(),
                  myTg: myTg,
                  myName: myName,
                  query: q,
                  onLong: (name) => _onLong(d.id, d.data(), name),
                ),
              if (g != null) _GlobalResults(future: g, onTap: _openFound),
              if (docs.isEmpty && _query.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(40),
                  child: Text('Пока нет чатов.\nНайдите друга через поиск вверху', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
                ),
            ]);
          },
        ),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: _tab == 0
            ? const Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.local_fire_department, color: accent),
                SizedBox(width: 6),
                Text('EMBER', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2)),
              ])
            : const Text('Настройки'),
        actions: [
          if (_tab == 0)
            PopupMenuButton<String>(
              icon: const Icon(Icons.add),
              onSelected: (v) {
                if (v == 'group') {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => CreateGroupScreen(myTg: myTg, myName: myName)));
                } else {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => CreateChannelScreen(myTg: myTg, myName: myName)));
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'group', child: Text('Новая группа')),
                PopupMenuItem(value: 'channel', child: Text('Новый канал')),
              ],
            ),
          if (_tab == 1)
            IconButton(
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => ProfileScreen(uid: FirebaseAuth.instance.currentUser!.uid, isMe: true)),
              ),
            ),
        ],
      ),
      body: IndexedStack(index: _tab, children: [_chatsBody(), SettingsTab(me: widget.me)]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: surfaceDark,
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: [
          NavigationDestination(
            icon: Badge(isLabelVisible: _totalUnread > 0, label: Text('$_totalUnread'), child: const Icon(Icons.chat_bubble_outline)),
            selectedIcon: Badge(isLabelVisible: _totalUnread > 0, label: Text('$_totalUnread'), child: const Icon(Icons.chat_bubble)),
            label: 'Чаты',
          ),
          const NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Настройки'),
        ],
      ),
    );
  }
}

class _GlobalResults extends StatelessWidget {
  final Future<List<Map<String, dynamic>>> future;
  final void Function(Map<String, dynamic>) onTap;
  const _GlobalResults({required this.future, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: future,
      builder: (context, s) {
        if (s.hasError) {
          return Padding(padding: const EdgeInsets.all(16), child: Text('Ошибка поиска: ${s.error}', style: const TextStyle(color: Colors.grey)));
        }
        if (!s.hasData) {
          return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()));
        }
        final list = s.data!;
        if (list.isEmpty) {
          return const Padding(padding: EdgeInsets.all(16), child: Text('Никого не найдено', style: TextStyle(color: Colors.grey)));
        }
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 4),
            child: Text('Глобальный поиск', style: TextStyle(color: accent, fontWeight: FontWeight.bold)),
          ),
          for (final u in list)
            if (u['_kind'] == 'channel')
              ListTile(
                leading: CircleAvatar(backgroundColor: accent.withValues(alpha: 0.25), child: const Icon(Icons.campaign, color: accent)),
                title: Row(children: [
                  Flexible(child: Text((u['title'] as String?) ?? 'Канал', overflow: TextOverflow.ellipsis)),
                  if (u['verified'] == true) ...[const SizedBox(width: 4), const VerifiedBadge()],
                ]),
                subtitle: Text('@${u['username']} · канал'),
                onTap: () => onTap(u),
              )
            else
              ListTile(
                leading: UserAvatar(url: u['photo_url'] as String?, name: (u['display_name'] as String?) ?? '', radius: 22),
                title: Text((u['display_name'] as String?) ?? uname(u)),
                subtitle: Text('@${uname(u)}'),
                onTap: () => onTap(u),
              ),
        ]);
      },
    );
  }
}

class _ChatTile extends StatelessWidget {
  final String chatId, myTg, myName, query;
  final Map<String, dynamic> chat;
  final void Function(String name) onLong;
  const _ChatTile({
    super.key,
    required this.chatId,
    required this.chat,
    required this.myTg,
    required this.myName,
    required this.query,
    required this.onLong,
  });

  @override
  Widget build(BuildContext context) {
    final type = (chat['type'] as String?) ?? 'private';
    final lastMsg = (chat['last_msg'] as String?) ?? 'Нет сообщений';
    final lt = chat['last_time'];
    final time = lt is Timestamp ? chatTime(lt.toDate()) : '';
    final unread = (((chat['unread'] as Map?)?[myTg]) as num?)?.toInt() ?? 0;

    final trailing = Column(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.center, children: [
      Text(time, style: const TextStyle(color: Colors.grey, fontSize: 12)),
      if (unread > 0)
        Container(
          margin: const EdgeInsets.only(top: 4),
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
          decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(10)),
          child: Text('$unread', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
        ),
    ]);

    void open() => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => ChatScreen(chatId: chatId, myTg: myTg, myName: myName)),
        );

    if (type == 'private') {
      final users = ((chat['users'] as List?) ?? []).cast<String>();
      final target = users.firstWhere((u) => u != myTg, orElse: () => '');
      if (target.isEmpty) return const SizedBox.shrink();
      return UserLive(
        tg: target,
        builder: (context, d, uid) {
          final name = userName(d, target);
          final username = d == null ? target : uname(d);
          if (query.isNotEmpty && !_matches(query, name, username, lastMsg)) return const SizedBox.shrink();
          return ListTile(
            leading: UserAvatar(url: d?['photo_url'] as String?, name: name, radius: 26),
            title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text(lastMsg, maxLines: 1, overflow: TextOverflow.ellipsis),
            trailing: trailing,
            onTap: open,
            onLongPress: () => onLong(name),
          );
        },
      );
    }

    final title = (chat['title'] as String?) ?? 'Чат';
    if (query.isNotEmpty && !_matches(query, title, (chat['username'] as String?) ?? '', lastMsg)) {
      return const SizedBox.shrink();
    }
    final ember = chatId == emberChatId;
    return ListTile(
      leading: CircleAvatar(
        radius: 26,
        backgroundColor: accent.withValues(alpha: 0.25),
        child: Icon(ember ? Icons.local_fire_department : (type == 'channel' ? Icons.campaign : Icons.group), color: accent),
      ),
      title: Row(children: [
        Flexible(child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis)),
        if (chat['verified'] == true) ...[const SizedBox(width: 4), const VerifiedBadge()],
      ]),
      subtitle: Text(lastMsg, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: trailing,
      onTap: open,
      onLongPress: () => onLong(title),
    );
  }
}
