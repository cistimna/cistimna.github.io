import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'chat_screen.dart';
import 'config.dart';
import 'profile_screen.dart';
import 'widgets.dart';

int _ms(JsonDoc d) {
  final t = d.data()['last_time'];
  return t is Timestamp ? t.millisecondsSinceEpoch : DateTime.now().millisecondsSinceEpoch;
}

class ChatsListScreen extends StatefulWidget {
  final Map<String, dynamic> me;
  const ChatsListScreen({super.key, required this.me});
  @override
  State<ChatsListScreen> createState() => _ChatsListScreenState();
}

class _ChatsListScreenState extends State<ChatsListScreen> {
  final _q = TextEditingController();
  String _query = '';
  Future<List<Map<String, dynamic>>>? _global;

  String get myTg => widget.me['tg_username'] as String;

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  void _onSearch(String v) {
    final t = v.trim();
    final c = cleanTg(t);
    setState(() {
      _query = t;
      _global = c.length >= 2 ? _runGlobal(c) : null;
    });
  }

  /// Поиск людей по началу username (как глобальный поиск в Telegram).
  Future<List<Map<String, dynamic>>> _runGlobal(String q) async {
    final snap = await FirebaseFirestore.instance
        .collection('users')
        .where('tg_username', isGreaterThanOrEqualTo: q)
        .where('tg_username', isLessThan: '$q\uf8ff')
        .limit(30)
        .get();
    final byTg = <String, List<JsonDoc>>{};
    for (final d in snap.docs) {
      final tg = d.data()['tg_username'] as String?;
      if (tg == null || tg == myTg) continue;
      byTg.putIfAbsent(tg, () => []).add(d);
    }
    return byTg.values.map((l) {
      final best = latestUserDoc(l)!;
      return <String, dynamic>{...best.data(), '_uid': best.id};
    }).toList();
  }

  Future<void> _openWith(Map<String, dynamic> u) async {
    final t = u['tg_username'] as String;
    final db = FirebaseFirestore.instance;
    try {
      final mine = await db.collection('chats').where('users', arrayContains: myTg).get();
      String? chatId;
      for (final d in mine.docs) {
        if (((d.data()['users'] as List?) ?? []).contains(t)) {
          chatId = d.id;
          break;
        }
      }
      if (chatId == null) {
        final ids = [myTg, t]..sort();
        chatId = ids.join('__');
        await db.collection('chats').doc(chatId).set({'users': ids, 'last_time': FieldValue.serverTimestamp()});
      }
      if (!mounted) return;
      _q.clear();
      setState(() {
        _query = '';
        _global = null;
      });
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PrivateChatScreen(
            chatId: chatId!,
            myTg: myTg,
            targetTg: t,
            targetName: (u['display_name'] as String?) ?? t,
            targetUid: (u['_uid'] as String?) ?? '',
          ),
        ),
      );
    } catch (e) {
      if (mounted) snack(context, 'Ошибка: $e');
    }
  }

  Future<void> _deleteChatData(String chatId) async {
    final db = FirebaseFirestore.instance;
    final msgs = db.collection('chats').doc(chatId).collection('messages');
    while (true) {
      final snap = await msgs.limit(400).get();
      if (snap.docs.isEmpty) break;
      final batch = db.batch();
      for (final d in snap.docs) {
        batch.delete(d.reference);
      }
      await batch.commit();
    }
    await db.collection('chats').doc(chatId).delete();
  }

  void _deleteChat(String chatId, String name) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить чат?'),
        content: Text('Вся переписка с $name будет удалена у обоих. Продолжить?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ОТМЕНА')),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              try {
                await _deleteChatData(chatId);
              } catch (e) {
                if (mounted) snack(context, 'Не удалось удалить: $e');
              }
            },
            child: const Text('УДАЛИТЬ', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Widget _searchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
      child: TextField(
        controller: _q,
        onChanged: _onSearch,
        autocorrect: false,
        decoration: InputDecoration(
          hintText: 'Поиск',
          prefixIcon: const Icon(Icons.search),
          suffixIcon: _query.isEmpty
              ? null
              : IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () {
                    _q.clear();
                    _onSearch('');
                  },
                ),
          filled: true,
          fillColor: surfaceDark,
          contentPadding: EdgeInsets.zero,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final me = widget.me;
    return Scaffold(
      appBar: AppBar(
        title: const Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.local_fire_department, color: accent),
          SizedBox(width: 6),
          Text('EMBER', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2)),
        ]),
        actions: [
          IconButton(
            icon: UserAvatar(url: me['photo_url'] as String?, name: (me['display_name'] as String?) ?? '', radius: 15),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ProfileScreen(uid: FirebaseAuth.instance.currentUser!.uid, isMe: true)),
            ),
          ),
        ],
      ),
      body: Column(children: [
        _searchBar(),
        Expanded(
          child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance.collection('chats').where('users', arrayContains: myTg).snapshots(),
            builder: (context, snap) {
              if (snap.hasError) return Center(child: Text('Ошибка: ${snap.error}'));
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final docs = snap.data!.docs.toList()..sort((a, b) => _ms(b).compareTo(_ms(a)));
              final q = _query.toLowerCase();
              final g = _global;
              final tiles = <Widget>[];
              for (final d in docs) {
                final chat = d.data();
                final users = ((chat['users'] as List?) ?? []).cast<String>();
                final target = users.firstWhere((u) => u != myTg, orElse: () => '');
                if (target.isEmpty) continue;
                final lt = chat['last_time'];
                tiles.add(_ChatTile(
                  key: ValueKey(d.id),
                  chatId: d.id,
                  myTg: myTg,
                  target: target,
                  lastMsg: (chat['last_msg'] as String?) ?? 'Нет сообщений',
                  time: lt is Timestamp ? chatTime(lt.toDate()) : '',
                  query: q,
                  onDelete: (name) => _deleteChat(d.id, name),
                ));
              }
              return ListView(children: [
                ...tiles,
                if (g != null) _GlobalResults(future: g, onTap: _openWith),
                if (docs.isEmpty && _query.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(40),
                    child: Text('Пока нет чатов.\nНайдите друга через поиск вверху', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
                  ),
              ]);
            },
          ),
        ),
      ]),
    );
  }
}

class _GlobalResults extends StatelessWidget {
  final Future<List<Map<String, dynamic>>> future;
  final void Function(Map<String, dynamic>) onTap;
  const _GlobalResults({required this.future, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: future,
      builder: (context, s) {
        if (s.hasError) {
          return Padding(padding: const EdgeInsets.all(16), child: Text('Ошибка поиска: ${s.error}', style: const TextStyle(color: Colors.grey)));
        }
        if (!s.hasData) {
          return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()));
        }
        final list = s.data!;
        if (list.isEmpty) {
          return const Padding(padding: EdgeInsets.all(16), child: Text('Никого не найдено', style: TextStyle(color: Colors.grey)));
        }
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 4),
            child: Text('Глобальный поиск', style: TextStyle(color: accent, fontWeight: FontWeight.bold)),
          ),
          for (final u in list)
            ListTile(
              leading: UserAvatar(url: u['photo_url'] as String?, name: (u['display_name'] as String?) ?? '', radius: 22),
              title: Text((u['display_name'] as String?) ?? (u['tg_username'] as String)),
              subtitle: Text('@${u['tg_username']}'),
              onTap: () => onTap(u),
            ),
        ]);
      },
    );
  }
}

class _ChatTile extends StatelessWidget {
  final String chatId, myTg, target, lastMsg, time, query;
  final void Function(String name) onDelete;
  const _ChatTile({
    super.key,
    required this.chatId,
    required this.myTg,
    required this.target,
    required this.lastMsg,
    required this.time,
    required this.query,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').where('tg_username', isEqualTo: target).snapshots(),
      builder: (context, snap) {
        var name = target;
        String? photo;
        var uid = '';
        final u = snap.hasData ? latestUserDoc(snap.data!.docs) : null;
        if (u != null) {
          final ud = u.data();
          name = (ud['display_name'] as String?) ?? target;
          photo = ud['photo_url'] as String?;
          uid = u.id;
        }
        if (query.isNotEmpty) {
          final qq = query.replaceFirst(RegExp(r'^@+'), '');
          final hit = name.toLowerCase().contains(query) || target.contains(qq) || lastMsg.toLowerCase().contains(query);
          if (!hit) return const SizedBox.shrink();
        }
        return ListTile(
          leading: UserAvatar(url: photo, name: name, radius: 26),
          title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(lastMsg, maxLines: 1, overflow: TextOverflow.ellipsis),
          trailing: Text(time, style: const TextStyle(color: Colors.grey, fontSize: 12)),
          onLongPress: () => onDelete(name),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => PrivateChatScreen(chatId: chatId, myTg: myTg, targetTg: target, targetName: name, targetUid: uid),
            ),
          ),
        );
      },
    );
  }
}
