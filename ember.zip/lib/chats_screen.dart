import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'chat_screen.dart';
import 'config.dart';
import 'profile_screen.dart';
import 'widgets.dart';

int _ms(JsonDoc d) {
  final t = d.data()['last_time'];
  return t is Timestamp ? t.millisecondsSinceEpoch : DateTime.now().millisecondsSinceEpoch;
}

class ChatsListScreen extends StatelessWidget {
  final Map<String, dynamic> me;
  const ChatsListScreen({super.key, required this.me});

  String get myTg => me['tg_username'] as String;

  void _addChat(BuildContext context) {
    final sc = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Новый чат'),
        content: TextField(controller: sc, autofocus: true, autocorrect: false, decoration: const InputDecoration(hintText: 'Username друга')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ОТМЕНА')),
          TextButton(
            onPressed: () async {
              final t = cleanTg(sc.text);
              if (t.isEmpty || t == myTg) return;
              try {
                final db = FirebaseFirestore.instance;
                final mine = await db.collection('chats').where('users', arrayContains: myTg).get();
                final exists = mine.docs.any((d) => ((d.data()['users'] as List?) ?? []).contains(t));
                if (!exists) {
                  final ids = [myTg, t]..sort();
                  await db.collection('chats').doc(ids.join('__')).set({'users': ids, 'last_time': FieldValue.serverTimestamp()});
                }
                if (ctx.mounted) Navigator.pop(ctx);
              } catch (e) {
                if (ctx.mounted) snack(ctx, 'Ошибка: $e');
              }
            },
            child: const Text('ОК'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteChatData(String chatId) async {
    final db = FirebaseFirestore.instance;
    final msgs = db.collection('chats').doc(chatId).collection('messages');
    while (true) {
      final snap = await msgs.limit(400).get();
      if (snap.docs.isEmpty) break;
      final batch = db.batch();
      for (final d in snap.docs) {
        batch.delete(d.reference);
      }
      await batch.commit();
    }
    await db.collection('chats').doc(chatId).delete();
  }

  void _deleteChat(BuildContext context, String chatId, String name) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить чат?'),
        content: Text('Вся переписка с $name будет удалена у обоих. Продолжить?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ОТМЕНА')),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              try {
                await _deleteChatData(chatId);
              } catch (e) {
                if (context.mounted) snack(context, 'Не удалось удалить: $e');
              }
            },
            child: const Text('УДАЛИТЬ', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.local_fire_department, color: accent),
          SizedBox(width: 6),
          Text('EMBER', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2)),
        ]),
        actions: [
          IconButton(
            icon: UserAvatar(url: me['photo_url'] as String?, name: (me['display_name'] as String?) ?? '', radius: 15),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ProfileScreen(uid: FirebaseAuth.instance.currentUser!.uid, isMe: true)),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(onPressed: () => _addChat(context), child: const Icon(Icons.message)),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('chats').where('users', arrayContains: myTg).snapshots(),
        builder: (context, snap) {
          if (snap.hasError) return Center(child: Text('Ошибка: ${snap.error}'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snap.data!.docs.toList()..sort((a, b) => _ms(b).compareTo(_ms(a)));
          if (docs.isEmpty) {
            return const Center(child: Text('Нет активных чатов', style: TextStyle(color: Colors.grey)));
          }
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, i) {
              final chat = docs[i].data();
              final users = ((chat['users'] as List?) ?? []).cast<String>();
              final target = users.firstWhere((u) => u != myTg, orElse: () => '');
              if (target.isEmpty) return const SizedBox.shrink();
              return _ChatTile(
                chatId: docs[i].id,
                myTg: myTg,
                target: target,
                lastMsg: (chat['last_msg'] as String?) ?? 'Нет сообщений',
                onDelete: (name) => _deleteChat(context, docs[i].id, name),
              );
            },
          );
        },
      ),
    );
  }
}

class _ChatTile extends StatelessWidget {
  final String chatId, myTg, target, lastMsg;
  final void Function(String name) onDelete;
  const _ChatTile({required this.chatId, required this.myTg, required this.target, required this.lastMsg, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').where('tg_username', isEqualTo: target).snapshots(),
      builder: (context, snap) {
        var name = target;
        String? photo;
        var uid = '';
        final u = snap.hasData ? latestUserDoc(snap.data!.docs) : null;
        if (u != null) {
          final ud = u.data();
          name = (ud['display_name'] as String?) ?? target;
          photo = ud['photo_url'] as String?;
          uid = u.id;
        }
        return ListTile(
          leading: UserAvatar(url: photo, name: name, radius: 25),
          title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(lastMsg, maxLines: 1, overflow: TextOverflow.ellipsis),
          onLongPress: () => onDelete(name),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => PrivateChatScreen(chatId: chatId, myTg: myTg, targetTg: target, targetName: name, targetUid: uid),
            ),
          ),
        );
      },
    );
  }
}
