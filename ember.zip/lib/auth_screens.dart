import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'accounts.dart';
import 'chats_screen.dart';
import 'config.dart';
import 'widgets.dart';

// ---------- Вход: почта + пароль, либо тестовый логин + пароль ----------
class LoginScreen extends StatefulWidget {
  final bool addMode;
  const LoginScreen({super.key, this.addMode = false});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _l = TextEditingController();
  final _p = TextEditingController();
  bool _busy = false;
  bool _hide = true;
  int _fails = 0;
  DateTime? _lockUntil;

  @override
  void dispose() {
    _l.dispose();
    _p.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final input = _l.text.trim();
    if (input.isEmpty || _p.text.isEmpty) return;
    if (input.contains('@')) {
      await _loginEmail(input.toLowerCase());
    } else {
      await _loginTest();
    }
  }

  Future<void> _loginEmail(String email) async {
    final saved = await AccountStore.load();
    final cand = SavedAccount('e', email);
    if (!saved.any(cand.sameAs) && saved.length >= AccountStore.maxAccounts) {
      if (mounted) snack(context, 'На устройстве уже 2 аккаунта. Уберите один в настройках.');
      return;
    }
    setState(() => _busy = true);
    try {
      final cred = await FirebaseAuth.instance.signInWithEmailAndPassword(email: email, password: _p.text);
      final u = cred.user!;
      if (u.emailVerified) await AccountStore.add(SavedAccount('e', email, u.uid));
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } catch (e) {
      if (mounted) snack(context, authErrorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _loginTest() async {
    final lock = _lockUntil;
    if (lock != null && DateTime.now().isBefore(lock)) {
      snack(context, 'Слишком много попыток, подождите минуту');
      return;
    }
    final idx = testAccountIndex(_l.text, _p.text);
    if (idx < 0) {
      _fails++;
      if (_fails >= 5) {
        _fails = 0;
        _lockUntil = DateTime.now().add(const Duration(minutes: 1));
      }
      snack(context, 'Неверный логин или пароль');
      return;
    }
    _fails = 0;
    final tg = 'ember_test_${idx + 1}';
    final saved = await AccountStore.load();
    final cand = SavedAccount('t', tg);
    if (!saved.any(cand.sameAs) && saved.length >= AccountStore.maxAccounts) {
      if (mounted) snack(context, 'На устройстве уже 2 аккаунта. Уберите один в настройках.');
      return;
    }
    setState(() => _busy = true);
    try {
      await enterAccount(tg);
      await AccountStore.add(cand);
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } catch (e) {
      await FirebaseAuth.instance.signOut();
      if (mounted) snack(context, 'Ошибка входа: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _reset() async {
    final email = _l.text.trim().toLowerCase();
    if (!email.contains('@')) {
      snack(context, 'Введите почту в первое поле');
      return;
    }
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
      if (mounted) snack(context, 'Письмо для сброса пароля отправлено. Проверьте также «Спам».');
    } catch (e) {
      if (mounted) snack(context, authErrorText(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: widget.addMode ? AppBar(title: const Text('Добавить аккаунт')) : null,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(30),
            child: Column(children: [
              const Icon(Icons.local_fire_department, size: 110, color: accent),
              const SizedBox(height: 10),
              const Text('EMBER', style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold, color: accent, letterSpacing: 4)),
              const SizedBox(height: 40),
              TextField(
                controller: _l,
                keyboardType: TextInputType.emailAddress,
                autocorrect: false,
                enableSuggestions: false,
                decoration: const InputDecoration(labelText: 'Почта или логин', filled: true),
              ),
              const SizedBox(height: 15),
              TextField(
                controller: _p,
                obscureText: _hide,
                autocorrect: false,
                enableSuggestions: false,
                onSubmitted: (_) => _login(),
                decoration: InputDecoration(
                  labelText: 'Пароль',
                  filled: true,
                  suffixIcon: IconButton(icon: Icon(_hide ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => _hide = !_hide)),
                ),
              ),
              const SizedBox(height: 30),
              _busy
                  ? const CircularProgressIndicator()
                  : ElevatedButton(
                      onPressed: _login,
                      style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
                      child: const Text('ВОЙТИ'),
                    ),
              const SizedBox(height: 10),
              TextButton(onPressed: _reset, child: const Text('Забыли пароль?', style: TextStyle(color: Colors.grey))),
              TextButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SignUpScreen())),
                child: const Text('Регистрация'),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

// ---------- Регистрация по почте ----------
class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});
  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _e = TextEditingController();
  final _p = TextEditingController();
  final _p2 = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _e.dispose();
    _p.dispose();
    _p2.dispose();
    super.dispose();
  }

  Future<void> _signUp() async {
    final email = _e.text.trim().toLowerCase();
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email)) {
      snack(context, 'Неверный адрес почты');
      return;
    }
    if (_p.text.length < 6) {
      snack(context, 'Пароль — минимум 6 символов');
      return;
    }
    if (_p.text != _p2.text) {
      snack(context, 'Пароли не совпадают');
      return;
    }
    setState(() => _busy = true);
    try {
      final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email, password: _p.text);
      try {
        await cred.user!.sendEmailVerification();
      } catch (_) {}
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } catch (e) {
      if (mounted) snack(context, authErrorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Регистрация')),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(children: [
              const Icon(Icons.mail_outline, size: 64, color: accent),
              const SizedBox(height: 12),
              const Text('Мы отправим на почту письмо со ссылкой для подтверждения.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 24),
              TextField(controller: _e, keyboardType: TextInputType.emailAddress, autocorrect: false, decoration: const InputDecoration(labelText: 'Почта', filled: true)),
              const SizedBox(height: 15),
              TextField(controller: _p, obscureText: true, decoration: const InputDecoration(labelText: 'Пароль (от 6 символов)', filled: true)),
              const SizedBox(height: 15),
              TextField(controller: _p2, obscureText: true, decoration: const InputDecoration(labelText: 'Повторите пароль', filled: true)),
              const SizedBox(height: 25),
              _busy
                  ? const CircularProgressIndicator()
                  : ElevatedButton(
                      onPressed: _signUp,
                      style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
                      child: const Text('ЗАРЕГИСТРИРОВАТЬСЯ'),
                    ),
            ]),
          ),
        ),
      ),
    );
  }
}

// ---------- Ожидание подтверждения почты ----------
class VerifyEmailScreen extends StatefulWidget {
  final User user;
  const VerifyEmailScreen({super.key, required this.user});
  @override
  State<VerifyEmailScreen> createState() => _VerifyEmailScreenState();
}

class _VerifyEmailScreenState extends State<VerifyEmailScreen> with WidgetsBindingObserver {
  bool _busy = false;
  DateTime? _nextSend;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _check(silent: true);
  }

  Future<void> _check({bool silent = false}) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final u = FirebaseAuth.instance.currentUser;
      await u?.reload();
      final fresh = FirebaseAuth.instance.currentUser;
      if (fresh != null && fresh.emailVerified) {
        await fresh.getIdToken(true);
      } else if (!silent && mounted) {
        snack(context, 'Почта ещё не подтверждена. Откройте письмо и нажмите на ссылку.');
      }
    } catch (e) {
      if (!silent && mounted) snack(context, authErrorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _resend() async {
    final n = _nextSend;
    if (n != null && DateTime.now().isBefore(n)) {
      snack(context, 'Подождите минуту перед повторной отправкой');
      return;
    }
    try {
      await FirebaseAuth.instance.currentUser?.sendEmailVerification();
      _nextSend = DateTime.now().add(const Duration(seconds: 60));
      if (mounted) snack(context, 'Письмо отправлено. Проверьте также «Спам».');
    } catch (e) {
      if (mounted) snack(context, authErrorText(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final email = FirebaseAuth.instance.currentUser?.email ?? widget.user.email ?? '';
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(30),
            child: Column(children: [
              const Icon(Icons.mark_email_unread_outlined, size: 80, color: accent),
              const SizedBox(height: 20),
              const Text('Подтвердите почту', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Text(
                'Мы отправили письмо на\n$email\nОткройте его, нажмите на ссылку и вернитесь сюда.',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.grey),
              ),
              const SizedBox(height: 30),
              _busy
                  ? const CircularProgressIndicator()
                  : ElevatedButton(
                      onPressed: () => _check(),
                      style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
                      child: const Text('Я ПОДТВЕРДИЛ'),
                    ),
              const SizedBox(height: 10),
              TextButton(onPressed: _resend, child: const Text('Отправить письмо ещё раз')),
              TextButton(
                onPressed: () => FirebaseAuth.instance.signOut(),
                child: const Text('Выйти / другая почта', style: TextStyle(color: Colors.grey)),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

// ---------- Обновить токен (после подтверждения почты) и открыть профиль ----------
class TokenGate extends StatefulWidget {
  final User user;
  const TokenGate({super.key, required this.user});
  @override
  State<TokenGate> createState() => _TokenGateState();
}

class _TokenGateState extends State<TokenGate> {
  late final Future<void> _f = widget.user.getIdToken(isPasswordUser(widget.user)).then((_) {}).catchError((_) {});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<void>(
      future: _f,
      builder: (context, s) {
        if (s.connectionState != ConnectionState.done) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        return ProfileGate(uid: widget.user.uid);
      },
    );
  }
}

// ---------- Профиль: ждём документ, затем настройка профиля или список чатов ----------
class ProfileGate extends StatelessWidget {
  final String uid;
  const ProfileGate({super.key, required this.uid});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
      builder: (context, snap) {
        if (snap.hasError) {
          return Scaffold(
            body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Ошибка: ${snap.error}'))),
          );
        }
        if (!snap.hasData) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        final d = snap.data!.data();
        if (d == null || d['tg_username'] == null) {
          if (isPasswordUser(FirebaseAuth.instance.currentUser)) return const ProfileSetupScreen();
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (d['display_name'] == null) return const NameSetupScreen();
        return ChatsListScreen(me: d);
      },
    );
  }
}

/// Первый вход по почте: выбираем имя и username.
class ProfileSetupScreen extends StatefulWidget {
  const ProfileSetupScreen({super.key});
  @override
  State<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}

class _ProfileSetupScreenState extends State<ProfileSetupScreen> {
  final _n = TextEditingController();
  final _u = TextEditingController();
  bool _busy = false;
  String? _err;

  @override
  void dispose() {
    _n.dispose();
    _u.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = _n.text.trim();
    final un = _u.text.trim().toLowerCase().replaceFirst(RegExp(r'^@+'), '');
    if (name.isEmpty) {
      setState(() => _err = 'Введите имя');
      return;
    }
    if (!RegExp(r'^[a-z][a-z0-9_]{4,31}$').hasMatch(un)) {
      setState(() => _err = 'Username: 5–32 символа, латиница, цифры и _, начинается с буквы');
      return;
    }
    final uid = FirebaseAuth.instance.currentUser!.uid;
    setState(() {
      _busy = true;
      _err = null;
    });
    final db = FirebaseFirestore.instance;
    try {
      await db.runTransaction((tx) async {
        final ref = db.collection('usernames').doc(un);
        final snap = await tx.get(ref);
        if (snap.exists && snap.data()?['tg'] != uid) throw 'taken';
        tx.set(ref, {'tg': uid});
        tx.set(db.collection('users').doc(uid), {
          'tg_username': uid,
          'username': un,
          'display_name': name,
          'last_login': FieldValue.serverTimestamp(),
        });
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          _busy = false;
          _err = e == 'taken' ? 'Это имя уже занято' : 'Ошибка: $e';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(30),
            child: Column(children: [
              const Icon(Icons.local_fire_department, size: 80, color: accent),
              const SizedBox(height: 20),
              const Text('Почта подтверждена!', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              const Text('Осталось выбрать имя и username', style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 30),
              TextField(controller: _n, decoration: const InputDecoration(filled: true, labelText: 'Имя')),
              const SizedBox(height: 15),
              TextField(
                controller: _u,
                autocorrect: false,
                decoration: InputDecoration(filled: true, labelText: 'Username', prefixText: '@', errorText: _err, errorMaxLines: 3),
              ),
              const SizedBox(height: 24),
              _busy
                  ? const CircularProgressIndicator()
                  : ElevatedButton(
                      onPressed: _save,
                      style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
                      child: const Text('НАЧАТЬ'),
                    ),
              TextButton(onPressed: () => FirebaseAuth.instance.signOut(), child: const Text('Выйти', style: TextStyle(color: Colors.grey))),
            ]),
          ),
        ),
      ),
    );
  }
}

class NameSetupScreen extends StatefulWidget {
  const NameSetupScreen({super.key});
  @override
  State<NameSetupScreen> createState() => _NameSetupScreenState();
}

class _NameSetupScreenState extends State<NameSetupScreen> {
  final _c = TextEditingController();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final n = _c.text.trim();
    if (n.isEmpty) return;
    final uid = FirebaseAuth.instance.currentUser!.uid;
    await FirebaseFirestore.instance.collection('users').doc(uid).set({'display_name': n}, SetOptions(merge: true));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(30),
            child: Column(children: [
              const Icon(Icons.local_fire_department, size: 80, color: accent),
              const SizedBox(height: 20),
              const Text('Как тебя называть?', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 30),
              TextField(controller: _c, decoration: const InputDecoration(filled: true, hintText: 'Твоё имя')),
              const SizedBox(height: 20),
              ElevatedButton(onPressed: _save, child: const Text('НАЧАТЬ')),
              TextButton(onPressed: () => FirebaseAuth.instance.signOut(), child: const Text('Выйти')),
            ]),
          ),
        ),
      ),
    );
  }
}
