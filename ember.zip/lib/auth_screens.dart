import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'accounts.dart';
import 'chats_screen.dart';
import 'config.dart';
import 'widgets.dart';

// ---------- Вход (логин + пароль, тестовые аккаунты) ----------
class LoginScreen extends StatefulWidget {
  final bool addMode;
  const LoginScreen({super.key, this.addMode = false});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _l = TextEditingController();
  final _p = TextEditingController();
  bool _busy = false;
  bool _hide = true;
  int _fails = 0;
  DateTime? _lockUntil;

  @override
  void dispose() {
    _l.dispose();
    _p.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final lock = _lockUntil;
    if (lock != null && DateTime.now().isBefore(lock)) {
      snack(context, 'Слишком много попыток, подождите минуту');
      return;
    }
    final idx = testAccountIndex(_l.text, _p.text);
    if (idx < 0) {
      _fails++;
      if (_fails >= 5) {
        _fails = 0;
        _lockUntil = DateTime.now().add(const Duration(minutes: 1));
      }
      snack(context, 'Неверный логин или пароль');
      return;
    }
    _fails = 0;
    final tg = 'ember_test_${idx + 1}';
    final saved = await AccountStore.load();
    if (!saved.contains(tg) && saved.length >= AccountStore.maxAccounts) {
      if (mounted) snack(context, 'На устройстве уже 2 аккаунта. Уберите один в настройках.');
      return;
    }
    setState(() => _busy = true);
    try {
      await enterAccount(tg);
      await AccountStore.add(tg);
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } catch (e) {
      await FirebaseAuth.instance.signOut();
      if (mounted) snack(context, 'Ошибка входа: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: widget.addMode ? AppBar(title: const Text('Добавить аккаунт')) : null,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(30),
            child: Column(children: [
              const Icon(Icons.local_fire_department, size: 110, color: accent),
              const SizedBox(height: 10),
              const Text('EMBER', style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold, color: accent, letterSpacing: 4)),
              const SizedBox(height: 40),
              TextField(controller: _l, autocorrect: false, enableSuggestions: false, decoration: const InputDecoration(labelText: 'Логин', filled: true)),
              const SizedBox(height: 15),
              TextField(
                controller: _p,
                obscureText: _hide,
                autocorrect: false,
                enableSuggestions: false,
                onSubmitted: (_) => _login(),
                decoration: InputDecoration(
                  labelText: 'Пароль',
                  filled: true,
                  suffixIcon: IconButton(icon: Icon(_hide ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => _hide = !_hide)),
                ),
              ),
              const SizedBox(height: 30),
              _busy
                  ? const CircularProgressIndicator()
                  : ElevatedButton(
                      onPressed: _login,
                      style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
                      child: const Text('ВОЙТИ'),
                    ),
              const SizedBox(height: 10),
              TextButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SignUpScreen())),
                child: const Text('Регистрация'),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

// ---------- Регистрация (не работает, показывает плашку) ----------
class SignUpScreen extends StatelessWidget {
  const SignUpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Регистрация')),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(children: [
              const Plaque(),
              const SizedBox(height: 30),
              const TextField(enabled: false, decoration: InputDecoration(labelText: 'Придумайте логин', filled: true)),
              const SizedBox(height: 15),
              const TextField(enabled: false, obscureText: true, decoration: InputDecoration(labelText: 'Пароль', filled: true)),
              const SizedBox(height: 15),
              const TextField(enabled: false, obscureText: true, decoration: InputDecoration(labelText: 'Повторите пароль', filled: true)),
              const SizedBox(height: 25),
              const ElevatedButton(onPressed: null, style: ButtonStyle(minimumSize: WidgetStatePropertyAll(Size(double.infinity, 50))), child: Text('ЗАРЕГИСТРИРОВАТЬСЯ')),
            ]),
          ),
        ),
      ),
    );
  }
}

// ---------- Профиль: ждём документ, затем имя или список чатов ----------
class ProfileGate extends StatelessWidget {
  final String uid;
  const ProfileGate({super.key, required this.uid});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
      builder: (context, snap) {
        if (snap.hasError) {
          return Scaffold(
            body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Ошибка: ${snap.error}'))),
          );
        }
        final d = snap.data?.data();
        if (d == null || d['tg_username'] == null) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (d['display_name'] == null) return const NameSetupScreen();
        return ChatsListScreen(me: d);
      },
    );
  }
}

class NameSetupScreen extends StatefulWidget {
  const NameSetupScreen({super.key});
  @override
  State<NameSetupScreen> createState() => _NameSetupScreenState();
}

class _NameSetupScreenState extends State<NameSetupScreen> {
  final _c = TextEditingController();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final n = _c.text.trim();
    if (n.isEmpty) return;
    final uid = FirebaseAuth.instance.currentUser!.uid;
    await FirebaseFirestore.instance.collection('users').doc(uid).set({'display_name': n}, SetOptions(merge: true));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(30),
            child: Column(children: [
              const Icon(Icons.local_fire_department, size: 80, color: accent),
              const SizedBox(height: 20),
              const Text('Добро пожаловать в EMBER!', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              const Text('Как тебя называть?', style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 30),
              TextField(controller: _c, decoration: const InputDecoration(filled: true, hintText: 'Твоё имя')),
              const SizedBox(height: 20),
              ElevatedButton(onPressed: _save, child: const Text('НАЧАТЬ')),
              TextButton(onPressed: () => FirebaseAuth.instance.signOut(), child: const Text('Выйти')),
            ]),
          ),
        ),
      ),
    );
  }
}
