import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'chats_screen.dart';
import 'config.dart';
import 'widgets.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _u = TextEditingController();
  final _c = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _u.dispose();
    _c.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final tg = cleanTg(_u.text);
    final code = _c.text.trim();
    if (tg.isEmpty || code.isEmpty) return;
    setState(() => _busy = true);
    try {
      final db = FirebaseFirestore.instance;
      final auth = await db.collection('pending_auths').doc(tg).get();
      if (!auth.exists || auth.data()?['code']?.toString() != code) {
        if (mounted) snack(context, 'Неверный код');
        return;
      }
      final cred = await FirebaseAuth.instance.signInAnonymously();
      final uid = cred.user!.uid;
      final data = <String, dynamic>{'tg_username': tg, 'last_login': FieldValue.serverTimestamp()};
      // Каждый вход создаёт новый uid — переносим имя и аватар из прошлого профиля.
      try {
        final old = await db.collection('users').where('tg_username', isEqualTo: tg).get();
        final prev = latestUserDoc(old.docs.where((d) => d.id != uid));
        if (prev != null) {
          final p = prev.data();
          if (p['display_name'] != null) data['display_name'] = p['display_name'];
          if (p['photo_url'] != null) data['photo_url'] = p['photo_url'];
        }
      } catch (_) {}
      await db.collection('users').doc(uid).set(data, SetOptions(merge: true));
    } catch (e) {
      await FirebaseAuth.instance.signOut();
      if (mounted) snack(context, 'Ошибка входа: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(30),
            child: Column(children: [
              const Icon(Icons.local_fire_department, size: 110, color: emberOrange),
              const SizedBox(height: 10),
              const Text('EMBER', style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold, color: emberOrange, letterSpacing: 4)),
              const SizedBox(height: 40),
              TextField(controller: _u, autocorrect: false, decoration: const InputDecoration(labelText: 'Username в Telegram', filled: true)),
              const SizedBox(height: 15),
              TextField(controller: _c, autocorrect: false, decoration: const InputDecoration(labelText: 'Код подтверждения', filled: true)),
              const SizedBox(height: 30),
              _busy
                  ? const CircularProgressIndicator()
                  : ElevatedButton(
                      onPressed: _login,
                      style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
                      child: const Text('ВОЙТИ'),
                    ),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Ждёт, пока профиль появится в Firestore, и решает: регистрация или список чатов.
class ProfileGate extends StatelessWidget {
  final String uid;
  const ProfileGate({super.key, required this.uid});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
      builder: (context, snap) {
        if (snap.hasError) {
          return Scaffold(
            body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Ошибка: ${snap.error}'))),
          );
        }
        final d = snap.data?.data();
        if (d == null || d['tg_username'] == null) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (d['display_name'] == null) return const RegistrationScreen();
        return ChatsListScreen(me: d);
      },
    );
  }
}

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});
  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _c = TextEditingController();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final n = _c.text.trim();
    if (n.isEmpty) return;
    final uid = FirebaseAuth.instance.currentUser!.uid;
    await FirebaseFirestore.instance.collection('users').doc(uid).set({'display_name': n}, SetOptions(merge: true));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(30),
            child: Column(children: [
              const Icon(Icons.local_fire_department, size: 80, color: emberOrange),
              const SizedBox(height: 20),
              const Text('Добро пожаловать в EMBER!', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              const Text('Как тебя называть?', style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 30),
              TextField(controller: _c, decoration: const InputDecoration(filled: true, hintText: 'Твоё имя')),
              const SizedBox(height: 20),
              ElevatedButton(onPressed: _save, child: const Text('НАЧАТЬ')),
              TextButton(onPressed: () => FirebaseAuth.instance.signOut(), child: const Text('Выйти')),
            ]),
          ),
        ),
      ),
    );
  }
}
