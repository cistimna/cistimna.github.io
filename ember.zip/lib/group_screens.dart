import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'chat_screen.dart';
import 'config.dart';
import 'messaging.dart';
import 'widgets.dart';

class ChatRef {
  final String id;
  final Map<String, dynamic> data;
  const ChatRef(this.id, this.data);
}

/// «Переслать в…»: выбор чата, куда можно писать.
Future<ChatRef?> showForwardPicker(BuildContext context, {required String myTg}) {
  return showModalBottomSheet<ChatRef>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => SizedBox(
      height: MediaQuery.of(ctx).size.height * 0.7,
      child: Column(children: [
        const Padding(padding: EdgeInsets.all(16), child: Text('Переслать в…', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
        Expanded(
          child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance.collection('chats').where('users', arrayContains: myTg).snapshots(),
            builder: (context, snap) {
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final rows = <Widget>[];
              for (final d in snap.data!.docs) {
                final c = d.data();
                final type = (c['type'] as String?) ?? 'private';
                final admins = ((c['admins'] as List?) ?? []).cast<String>();
                if (type == 'channel' && !admins.contains(myTg)) continue;
                final ref = ChatRef(d.id, c);
                if (type == 'private') {
                  final target = ((c['users'] as List?) ?? []).cast<String>().firstWhere((u) => u != myTg, orElse: () => '');
                  if (target.isEmpty) continue;
                  rows.add(UserLive(
                    tg: target,
                    builder: (context, u, uid) => ListTile(
                      leading: UserAvatar(url: u?['photo_url'] as String?, name: userName(u, target), radius: 22),
                      title: Text(userName(u, target)),
                      onTap: () => Navigator.pop(ctx, ref),
                    ),
                  ));
                } else {
                  rows.add(ListTile(
                    leading: CircleAvatar(
                      backgroundColor: accent.withValues(alpha: 0.25),
                      child: Icon(type == 'channel' ? Icons.campaign : Icons.group, color: accent),
                    ),
                    title: Text((c['title'] as String?) ?? 'Чат'),
                    onTap: () => Navigator.pop(ctx, ref),
                  ));
                }
              }
              if (rows.isEmpty) return const Center(child: Text('Нет чатов', style: TextStyle(color: Colors.grey)));
              return ListView(children: rows);
            },
          ),
        ),
      ]),
    ),
  );
}

/// Список людей из ваших личных чатов с галочками.
class PartnerList extends StatefulWidget {
  final String myTg;
  final Set<String> selected;
  final Set<String> exclude;
  final void Function(String tg) onToggle;
  const PartnerList({super.key, required this.myTg, required this.selected, required this.exclude, required this.onToggle});
  @override
  State<PartnerList> createState() => _PartnerListState();
}

class _PartnerListState extends State<PartnerList> {
  late final Stream<QuerySnapshot<Map<String, dynamic>>> _s =
      FirebaseFirestore.instance.collection('chats').where('users', arrayContains: widget.myTg).snapshots();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: _s,
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final partners = <String>{};
        for (final d in snap.data!.docs) {
          final c = d.data();
          if (((c['type'] as String?) ?? 'private') != 'private') continue;
          for (final u in ((c['users'] as List?) ?? []).cast<String>()) {
            if (u != widget.myTg && !widget.exclude.contains(u)) partners.add(u);
          }
        }
        if (partners.isEmpty) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(30),
              child: Text('Некого добавлять.\nСначала начните личный чат с человеком через поиск.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
            ),
          );
        }
        return ListView(children: [
          for (final t in partners)
            UserLive(
              tg: t,
              builder: (context, d, uid) => CheckboxListTile(
                value: widget.selected.contains(t),
                onChanged: (_) => widget.onToggle(t),
                secondary: UserAvatar(url: d?['photo_url'] as String?, name: userName(d, t), radius: 22),
                title: Text(userName(d, t)),
                subtitle: Text('@${d == null ? t : uname(d)}'),
              ),
            ),
        ]);
      },
    );
  }
}

// ---------- Новая группа ----------
class CreateGroupScreen extends StatefulWidget {
  final String myTg, myName;
  const CreateGroupScreen({super.key, required this.myTg, required this.myName});
  @override
  State<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final _title = TextEditingController();
  final Set<String> _sel = {};
  bool _busy = false;

  @override
  void dispose() {
    _title.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    final t = _title.text.trim();
    if (t.isEmpty) {
      snack(context, 'Введите название группы');
      return;
    }
    if (_sel.isEmpty) {
      snack(context, 'Выберите хотя бы одного участника');
      return;
    }
    setState(() => _busy = true);
    try {
      final ref = FirebaseFirestore.instance.collection('chats').doc();
      await ref.set({
        'type': 'group',
        'title': t,
        'users': [widget.myTg, ..._sel],
        'admins': [widget.myTg],
        'created_by': widget.myTg,
        'last_time': FieldValue.serverTimestamp(),
        'last_msg': 'Группа создана',
      });
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => ChatScreen(chatId: ref.id, myTg: widget.myTg, myName: widget.myName)),
      );
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        snack(context, 'Ошибка: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Новая группа'),
        actions: [TextButton(onPressed: _busy ? null : _create, child: const Text('СОЗДАТЬ'))],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(controller: _title, maxLength: 40, decoration: const InputDecoration(labelText: 'Название группы', filled: true)),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 0, 20, 8),
          child: Align(alignment: Alignment.centerLeft, child: Text('УЧАСТНИКИ (из ваших личных чатов)', style: TextStyle(color: Colors.grey, fontSize: 13))),
        ),
        Expanded(
          child: PartnerList(
            myTg: widget.myTg,
            selected: _sel,
            exclude: const {},
            onToggle: (t) => setState(() => _sel.contains(t) ? _sel.remove(t) : _sel.add(t)),
          ),
        ),
      ]),
    );
  }
}

// ---------- Добавить участников в группу ----------
class AddMembersScreen extends StatefulWidget {
  final String myTg;
  final Set<String> exclude;
  const AddMembersScreen({super.key, required this.myTg, required this.exclude});
  @override
  State<AddMembersScreen> createState() => _AddMembersScreenState();
}

class _AddMembersScreenState extends State<AddMembersScreen> {
  final Set<String> _sel = {};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Добавить участников'),
        actions: [TextButton(onPressed: () => Navigator.pop(context, _sel.toList()), child: const Text('ГОТОВО'))],
      ),
      body: PartnerList(
        myTg: widget.myTg,
        selected: _sel,
        exclude: widget.exclude,
        onToggle: (t) => setState(() => _sel.contains(t) ? _sel.remove(t) : _sel.add(t)),
      ),
    );
  }
}

// ---------- Новый канал ----------
class CreateChannelScreen extends StatefulWidget {
  final String myTg, myName;
  const CreateChannelScreen({super.key, required this.myTg, required this.myName});
  @override
  State<CreateChannelScreen> createState() => _CreateChannelScreenState();
}

class _CreateChannelScreenState extends State<CreateChannelScreen> {
  final _title = TextEditingController();
  final _handle = TextEditingController();
  bool _busy = false;
  String? _err;

  @override
  void dispose() {
    _title.dispose();
    _handle.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    final title = _title.text.trim();
    final handle = _handle.text.trim().toLowerCase().replaceFirst(RegExp(r'^@+'), '');
    if (title.isEmpty) {
      setState(() => _err = 'Введите название канала');
      return;
    }
    if (!RegExp(r'^[a-z][a-z0-9_]{4,31}$').hasMatch(handle)) {
      setState(() => _err = 'Адрес: 5–32 символа, латиница, цифры и _, начинается с буквы');
      return;
    }
    setState(() {
      _busy = true;
      _err = null;
    });
    final db = FirebaseFirestore.instance;
    final ref = db.collection('chats').doc();
    try {
      await db.runTransaction((tx) async {
        final reg = db.collection('usernames').doc(handle);
        final s = await tx.get(reg);
        if (s.exists) throw 'taken';
        tx.set(ref, {
          'type': 'channel',
          'title': title,
          'username': handle,
          'verified': false,
          'admins': [widget.myTg],
          'users': [widget.myTg],
          'last_time': FieldValue.serverTimestamp(),
          'last_msg': 'Канал создан',
        });
        tx.set(reg, {'chat': ref.id});
      });
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => ChatScreen(chatId: ref.id, myTg: widget.myTg, myName: widget.myName)),
      );
    } catch (e) {
      if (mounted) {
        setState(() {
          _busy = false;
          _err = e == 'taken' ? 'Этот адрес уже занят' : 'Ошибка: $e';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Новый канал')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          const Icon(Icons.campaign, size: 64, color: accent),
          const SizedBox(height: 12),
          const Text('В канале пишут только администраторы, а подписаться может любой пользователь.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 24),
          TextField(controller: _title, maxLength: 40, decoration: const InputDecoration(labelText: 'Название канала', filled: true)),
          const SizedBox(height: 8),
          TextField(
            controller: _handle,
            autocorrect: false,
            decoration: InputDecoration(labelText: 'Адрес канала', prefixText: '@', filled: true, errorText: _err, errorMaxLines: 3),
          ),
          const SizedBox(height: 24),
          _busy
              ? const CircularProgressIndicator()
              : ElevatedButton(
                  onPressed: _create,
                  style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
                  child: const Text('СОЗДАТЬ КАНАЛ'),
                ),
        ]),
      ),
    );
  }
}

// ---------- Информация о группе / канале ----------
class ChatInfoScreen extends StatelessWidget {
  final String chatId, myTg;
  const ChatInfoScreen({super.key, required this.chatId, required this.myTg});

  DocumentReference<Map<String, dynamic>> get _ref => FirebaseFirestore.instance.collection('chats').doc(chatId);

  Future<void> _subscribe(BuildContext context) async {
    try {
      await _ref.update({'users': FieldValue.arrayUnion([myTg])});
    } catch (e) {
      if (context.mounted) snack(context, 'Ошибка: $e');
    }
  }

  Future<void> _leave(BuildContext context) async {
    try {
      await _ref.update({'users': FieldValue.arrayRemove([myTg])});
      if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } catch (e) {
      if (context.mounted) snack(context, 'Ошибка: $e');
    }
  }

  void _delete(BuildContext context, String? handle, bool channel) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(channel ? 'Удалить канал?' : 'Удалить группу?'),
        content: const Text('Вся переписка будет удалена для всех. Это нельзя отменить.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ОТМЕНА')),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              try {
                await deleteChatCompletely(chatId, handle: handle);
                if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
              } catch (e) {
                if (context.mounted) snack(context, 'Не удалось удалить: $e');
              }
            },
            child: const Text('УДАЛИТЬ', style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
  }

  Future<void> _addMembers(BuildContext context, List<String> current) async {
    final picked = await Navigator.push<List<String>>(
      context,
      MaterialPageRoute(builder: (_) => AddMembersScreen(myTg: myTg, exclude: current.toSet())),
    );
    if (picked == null || picked.isEmpty) return;
    try {
      await _ref.update({'users': FieldValue.arrayUnion(picked)});
    } catch (e) {
      if (context.mounted) snack(context, 'Ошибка: $e');
    }
  }

  Widget _card(List<Widget> children) => Material(
        color: bubbleOther,
        borderRadius: BorderRadius.circular(16),
        clipBehavior: Clip.antiAlias,
        child: Column(children: children),
      );

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: _ref.snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return Scaffold(appBar: AppBar(), body: Center(child: Text('Ошибка: ${snap.error}')));
        if (!snap.hasData) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
        final c = snap.data!.data();
        if (c == null) return Scaffold(appBar: AppBar(), body: const Center(child: Text('Чат удалён')));
        final isChannel = c['type'] == 'channel';
        final users = ((c['users'] as List?) ?? []).cast<String>();
        final admins = ((c['admins'] as List?) ?? []).cast<String>();
        final isAdmin = admins.contains(myTg);
        final isMember = users.contains(myTg);
        final isEmber = chatId == emberChatId;
        final title = (c['title'] as String?) ?? 'Чат';
        final handle = c['username'] as String?;

        return Scaffold(
          appBar: AppBar(title: Text(isChannel ? 'Канал' : 'Группа')),
          body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
            const SizedBox(height: 8),
            Center(
              child: CircleAvatar(
                radius: 56,
                backgroundColor: accent.withValues(alpha: 0.25),
                child: Icon(isEmber ? Icons.local_fire_department : (isChannel ? Icons.campaign : Icons.group), size: 56, color: accent),
              ),
            ),
            const SizedBox(height: 12),
            Center(
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Flexible(child: Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
                if (c['verified'] == true) ...[const SizedBox(width: 6), const VerifiedBadge(size: 22)],
              ]),
            ),
            const SizedBox(height: 4),
            Center(child: Text(isChannel ? 'Подписчиков: ${users.length}' : 'Участников: ${users.length}', style: const TextStyle(color: Colors.grey))),
            if (handle != null && handle.isNotEmpty) Center(child: Text('@$handle', style: const TextStyle(color: accent))),
            const SizedBox(height: 20),
            if (isChannel && !isMember)
              ElevatedButton(
                onPressed: () => _subscribe(context),
                style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
                child: const Text('ПОДПИСАТЬСЯ'),
              ),
            if (!isChannel) ...[
              _card([
                if (isAdmin)
                  ListTile(
                    leading: const Icon(Icons.person_add_alt_1_outlined, color: accent),
                    title: const Text('Добавить участников', style: TextStyle(color: accent)),
                    onTap: () => _addMembers(context, users),
                  ),
                for (final t in users)
                  UserLive(
                    tg: t,
                    builder: (context, d, uid) => ListTile(
                      leading: UserAvatar(url: d?['photo_url'] as String?, name: userName(d, t), radius: 22),
                      title: Text(userName(d, t)),
                      subtitle: Text('@${d == null ? t : uname(d)}', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                      trailing: admins.contains(t)
                          ? const Text('админ', style: TextStyle(color: accent, fontSize: 12))
                          : (isAdmin
                              ? IconButton(
                                  icon: const Icon(Icons.person_remove_outlined, color: Colors.redAccent),
                                  onPressed: () => _ref.update({'users': FieldValue.arrayRemove([t])}),
                                )
                              : null),
                    ),
                  ),
              ]),
              const SizedBox(height: 16),
            ],
            if (isAdmin && !isEmber)
              _card([
                ListTile(
                  leading: const Icon(Icons.delete_outline, color: Colors.redAccent),
                  title: Text(isChannel ? 'Удалить канал' : 'Удалить группу', style: const TextStyle(color: Colors.redAccent)),
                  onTap: () => _delete(context, handle, isChannel),
                ),
              ])
            else if (isMember && !isEmber && !isAdmin)
              _card([
                ListTile(
                  leading: const Icon(Icons.logout, color: Colors.redAccent),
                  title: Text(isChannel ? 'Отписаться' : 'Покинуть группу', style: const TextStyle(color: Colors.redAccent)),
                  onTap: () => _leave(context),
                ),
              ]),
          ]),
        );
      },
    );
  }
}
