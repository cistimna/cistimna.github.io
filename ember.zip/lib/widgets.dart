import 'dart:convert';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'config.dart';

typedef JsonDoc = QueryDocumentSnapshot<Map<String, dynamic>>;

class UserAvatar extends StatelessWidget {
  final String? url;
  final String name;
  final double radius;
  const UserAvatar({super.key, this.url, required this.name, this.radius = 20});

  static final Map<String, Uint8List> _cache = {};

  @override
  Widget build(BuildContext context) {
    final u = url;
    if (u != null && u.isNotEmpty) {
      if (u.startsWith('data:image')) {
        final bytes = _cache.putIfAbsent(u, () => base64Decode(u.split(',').last));
        return CircleAvatar(radius: radius, backgroundImage: MemoryImage(bytes));
      }
      return CircleAvatar(radius: radius, backgroundImage: NetworkImage(u));
    }
    return CircleAvatar(
      radius: radius,
      backgroundColor: accent.withValues(alpha: 0.25),
      child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?', style: TextStyle(fontSize: radius * 0.8)),
    );
  }
}

const _videoExt = ['mp4', 'mov', 'mkv', 'webm', '3gp', 'avi', 'm4v'];

bool isVideoPath(String p) {
  final i = p.lastIndexOf('.');
  return i >= 0 && _videoExt.contains(p.substring(i + 1).toLowerCase());
}

String hhmm(DateTime d) => '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

String cleanTg(String s) => s.trim().replaceFirst(RegExp(r'^@+'), '').toLowerCase();

void snack(BuildContext c, String t) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(t)));

/// У одного username может быть несколько документов (каждый вход = новый anonymous uid).
/// Берём самый свежий по last_login.
JsonDoc? latestUserDoc(Iterable<JsonDoc> docs) {
  JsonDoc? best;
  for (final d in docs) {
    if (best == null) {
      best = d;
      continue;
    }
    final a = d.data()['last_login'];
    final b = best.data()['last_login'];
    if (a is Timestamp && (b is! Timestamp || a.compareTo(b) > 0)) best = d;
  }
  return best;
}

/// Плашка для экрана регистрации.
class Plaque extends StatelessWidget {
  const Plaque({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
      child: const Text(
        'отдела временно нет ведь Артём ленивая жопа',
        textAlign: TextAlign.center,
        style: TextStyle(color: plaqueBlue, fontWeight: FontWeight.w900, fontSize: 20, letterSpacing: 2, height: 1.4),
      ),
    );
  }
}

/// Время для списка чатов: сегодня — часы:минуты, иначе дата.
String chatTime(DateTime d) {
  final n = DateTime.now();
  if (d.year == n.year && d.month == n.month && d.day == n.day) return hhmm(d);
  return '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')}';
}

/// Публичное имя (@username); если не задано — внутренний id.
String uname(Map<String, dynamic> d) {
  final u = d['username'] as String?;
  return (u != null && u.isNotEmpty) ? u : ((d['tg_username'] as String?) ?? '');
}


/// Живые данные пользователя по внутреннему id (самый свежий профиль).
class UserLive extends StatefulWidget {
  final String tg;
  final Widget Function(BuildContext context, Map<String, dynamic>? data, String uid) builder;
  const UserLive({super.key, required this.tg, required this.builder});
  @override
  State<UserLive> createState() => _UserLiveState();
}

class _UserLiveState extends State<UserLive> {
  late Stream<QuerySnapshot<Map<String, dynamic>>> _s = _make();

  Stream<QuerySnapshot<Map<String, dynamic>>> _make() =>
      FirebaseFirestore.instance.collection('users').where('tg_username', isEqualTo: widget.tg).snapshots();

  @override
  void didUpdateWidget(covariant UserLive old) {
    super.didUpdateWidget(old);
    if (old.tg != widget.tg) _s = _make();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: _s,
      builder: (context, snap) {
        final u = snap.hasData ? latestUserDoc(snap.data!.docs) : null;
        return widget.builder(context, u?.data(), u?.id ?? '');
      },
    );
  }
}

String userName(Map<String, dynamic>? d, String fallback) => (d?['display_name'] as String?) ?? fallback;

class VerifiedBadge extends StatelessWidget {
  final double size;
  const VerifiedBadge({super.key, this.size = 16});
  @override
  Widget build(BuildContext context) => Icon(Icons.verified, color: accent, size: size);
}

/// «в сети» / «был(а) в сети ...»
String lastSeenText(dynamic ts) {
  if (ts is! Timestamp) return 'был(а) давно';
  final d = ts.toDate();
  final n = DateTime.now();
  if (n.difference(d).inSeconds < 100) return 'в сети';
  if (d.year == n.year && d.month == n.month && d.day == n.day) return 'был(а) в сети в ${hhmm(d)}';
  final y = n.subtract(const Duration(days: 1));
  if (d.year == y.year && d.month == y.month && d.day == y.day) return 'был(а) в сети вчера в ${hhmm(d)}';
  return 'был(а) в сети ${chatTime(d)}';
}
