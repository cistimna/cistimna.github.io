import 'dart:convert';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'config.dart';

typedef JsonDoc = QueryDocumentSnapshot<Map<String, dynamic>>;

class UserAvatar extends StatelessWidget {
  final String? url;
  final String name;
  final double radius;
  const UserAvatar({super.key, this.url, required this.name, this.radius = 20});

  static final Map<String, Uint8List> _cache = {};

  @override
  Widget build(BuildContext context) {
    final u = url;
    if (u != null && u.isNotEmpty) {
      if (u.startsWith('data:image')) {
        final bytes = _cache.putIfAbsent(u, () => base64Decode(u.split(',').last));
        return CircleAvatar(radius: radius, backgroundImage: MemoryImage(bytes));
      }
      return CircleAvatar(radius: radius, backgroundImage: NetworkImage(u));
    }
    return CircleAvatar(
      radius: radius,
      backgroundColor: accent.withValues(alpha: 0.25),
      child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?', style: TextStyle(fontSize: radius * 0.8)),
    );
  }
}

const _videoExt = ['mp4', 'mov', 'mkv', 'webm', '3gp', 'avi', 'm4v'];

bool isVideoPath(String p) {
  final i = p.lastIndexOf('.');
  return i >= 0 && _videoExt.contains(p.substring(i + 1).toLowerCase());
}

String hhmm(DateTime d) => '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

String cleanTg(String s) => s.trim().replaceFirst(RegExp(r'^@+'), '').toLowerCase();

void snack(BuildContext c, String t) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(t)));

/// У одного username может быть несколько документов (каждый вход = новый anonymous uid).
/// Берём самый свежий по last_login.
JsonDoc? latestUserDoc(Iterable<JsonDoc> docs) {
  JsonDoc? best;
  for (final d in docs) {
    if (best == null) {
      best = d;
      continue;
    }
    final a = d.data()['last_login'];
    final b = best.data()['last_login'];
    if (a is Timestamp && (b is! Timestamp || a.compareTo(b) > 0)) best = d;
  }
  return best;
}

/// Плашка для экрана регистрации.
class Plaque extends StatelessWidget {
  const Plaque({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
      child: const Text(
        'отдела временно нет ведь Артём ленивая жопа',
        textAlign: TextAlign.center,
        style: TextStyle(color: plaqueBlue, fontWeight: FontWeight.w900, fontSize: 20, letterSpacing: 2, height: 1.4),
      ),
    );
  }
}
