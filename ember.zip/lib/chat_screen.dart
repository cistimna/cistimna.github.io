import 'dart:convert';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'config.dart';
import 'profile_screen.dart';
import 'widgets.dart';

/// Фото хранится прямо в сообщении (base64). Документ Firestore ограничен ~1 МБ.
const _maxB64 = 900000;

class PickedImage {
  final Uint8List bytes;
  final String name;
  const PickedImage(this.bytes, this.name);
}

Widget _box(Widget child) => Container(width: 250, height: 250, color: Colors.black26, alignment: Alignment.center, child: child);

class _MemImage extends StatefulWidget {
  final String data;
  final double? width, height;
  final BoxFit fit;
  const _MemImage({required this.data, this.width, this.height, this.fit = BoxFit.cover});
  @override
  State<_MemImage> createState() => _MemImageState();
}

class _MemImageState extends State<_MemImage> {
  Uint8List? _bytes;

  @override
  void initState() {
    super.initState();
    try {
      _bytes = base64Decode(widget.data.split(',').last);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final b = _bytes;
    if (b == null) return _box(const Icon(Icons.broken_image, color: Colors.white38));
    return Image.memory(
      b,
      width: widget.width,
      height: widget.height,
      fit: widget.fit,
      gaplessPlayback: true,
      errorBuilder: (c, e, s) => _box(const Icon(Icons.broken_image, color: Colors.white38)),
    );
  }
}

class PrivateChatScreen extends StatefulWidget {
  final String chatId, myTg, targetTg, targetName, targetUid, targetUsername;
  const PrivateChatScreen({
    super.key,
    required this.chatId,
    required this.myTg,
    required this.targetTg,
    required this.targetName,
    required this.targetUid,
    required this.targetUsername,
  });
  @override
  State<PrivateChatScreen> createState() => _PrivateChatScreenState();
}

class _PrivateChatScreenState extends State<PrivateChatScreen> {
  final _msg = TextEditingController();
  final Set<String> _marked = {};
  late final Stream<QuerySnapshot<Map<String, dynamic>>> _stream;

  CollectionReference<Map<String, dynamic>> get _col => FirebaseFirestore.instance.collection('chats').doc(widget.chatId).collection('messages');
  DocumentReference<Map<String, dynamic>> get _chatRef => FirebaseFirestore.instance.collection('chats').doc(widget.chatId);

  @override
  void initState() {
    super.initState();
    _stream = _col.orderBy('timestamp', descending: true).limit(60).snapshots();
  }

  @override
  void dispose() {
    _msg.dispose();
    super.dispose();
  }

  Future<void> _touchChat(String last) async {
    try {
      await _chatRef.update({'last_time': FieldValue.serverTimestamp(), 'last_msg': last});
    } catch (_) {}
  }

  Future<void> _sendText() async {
    final t = _msg.text.trim();
    if (t.isEmpty) return;
    _msg.clear();
    try {
      await _col.add({
        'text': t,
        'sender_tg': widget.myTg,
        'timestamp': FieldValue.serverTimestamp(),
        'is_read': false,
        'hidden_for': <String>[],
      });
      await _touchChat(t);
    } catch (e) {
      if (mounted) snack(context, 'Не отправлено: $e');
    }
  }

  Future<void> _pickImages() async {
    final res = await ImagePicker().pickMultiImage(maxWidth: 1024, maxHeight: 1024, imageQuality: 55);
    if (res.isEmpty || !mounted) return;
    final items = <PickedImage>[];
    for (final x in res) {
      items.add(PickedImage(await x.readAsBytes(), x.name));
    }
    if (!mounted) return;
    final result = await Navigator.push<Map<String, dynamic>>(
      context,
      MaterialPageRoute(builder: (_) => MediaPreviewScreen(items: items)),
    );
    if (result == null) return;
    await _sendImages(result['images'] as List<PickedImage>, result['caption'] as String);
  }

  Future<void> _sendImages(List<PickedImage> imgs, String caption) async {
    var skipped = 0;
    for (final im in imgs) {
      final b64 = base64Encode(im.bytes);
      if (b64.length > _maxB64) {
        skipped++;
        continue;
      }
      try {
        await _col.add({
          'sender_tg': widget.myTg,
          'timestamp': FieldValue.serverTimestamp(),
          'image': 'data:image/jpeg;base64,$b64',
          'text': caption,
          'is_read': false,
          'hidden_for': <String>[],
        });
        await _touchChat('📷 Фото');
        caption = '';
      } catch (e) {
        if (mounted) snack(context, 'Не отправлено: $e');
      }
    }
    if (skipped > 0 && mounted) snack(context, 'Слишком тяжёлых фото пропущено: $skipped');
  }

  Future<void> _deleteMsg(String id, bool forAll) async {
    try {
      if (forAll) {
        await _col.doc(id).delete();
      } else {
        await _col.doc(id).update({'hidden_for': FieldValue.arrayUnion([widget.myTg])});
      }
    } catch (e) {
      if (mounted) snack(context, 'Ошибка: $e');
    }
  }

  void _markRead(List<JsonDoc> docs) {
    final unread = docs.where((d) {
      final m = d.data();
      return m['sender_tg'] == widget.targetTg && m['is_read'] != true && !_marked.contains(d.id);
    }).toList();
    if (unread.isEmpty) return;
    final batch = FirebaseFirestore.instance.batch();
    for (final d in unread) {
      _marked.add(d.id);
      batch.update(d.reference, {'is_read': true});
    }
    batch.commit().catchError((_) {});
  }

  void _showMenu(String id, bool mine) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.visibility_off),
            title: const Text('Удалить у меня'),
            onTap: () {
              Navigator.pop(ctx);
              _deleteMsg(id, false);
            },
          ),
          if (mine)
            ListTile(
              leading: const Icon(Icons.delete_forever, color: Colors.red),
              title: const Text('Удалить у обоих', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.pop(ctx);
                _deleteMsg(id, true);
              },
            ),
        ]),
      ),
    );
  }

  Widget _bubble(JsonDoc doc) {
    final m = doc.data();
    final isMe = m['sender_tg'] == widget.myTg;
    final text = (m['text'] as String?) ?? '';
    final img = m['image'] as String?;
    final ts = m['timestamp'];

    Widget? media;
    if (img != null && img.isNotEmpty) {
      media = GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MediaViewer(data: img, heroTag: doc.id))),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Hero(tag: doc.id, child: _MemImage(data: img, width: 250, height: 250)),
        ),
      );
    }

    return Align(
      key: ValueKey(doc.id),
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () => _showMenu(doc.id, isMe),
        child: Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
          margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(color: isMe ? bubbleMe : bubbleOther, borderRadius: BorderRadius.circular(14)),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (media != null) media,
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
              child: Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
                if (text.isNotEmpty) Flexible(child: Text(text)),
                if (text.isNotEmpty) const SizedBox(width: 10),
                Text(ts is Timestamp ? hhmm(ts.toDate()) : '--:--', style: const TextStyle(fontSize: 10, color: Colors.white54)),
                if (isMe) ...[
                  const SizedBox(width: 4),
                  Icon(m['is_read'] == true ? Icons.done_all : Icons.done, size: 14, color: accent),
                ],
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _input() {
    return SafeArea(
      top: false,
      child: Container(
        color: surfaceDark,
        padding: const EdgeInsets.all(8),
        child: Row(children: [
          IconButton(icon: const Icon(Icons.image), onPressed: _pickImages),
          Expanded(
            child: TextField(
              controller: _msg,
              minLines: 1,
              maxLines: 5,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(border: InputBorder.none, hintText: 'Сообщение'),
            ),
          ),
          IconButton(icon: const Icon(Icons.send, color: accent), onPressed: _sendText),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: InkWell(
          onTap: widget.targetUid.isEmpty
              ? null
              : () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileScreen(uid: widget.targetUid, isMe: false))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.targetName, style: const TextStyle(fontSize: 18)),
            Text('@${widget.targetUsername}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ]),
        ),
      ),
      body: Column(children: [
        Expanded(
          child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: _stream,
            builder: (context, snap) {
              if (snap.hasError) return Center(child: Text('Ошибка: ${snap.error}'));
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final docs = snap.data!.docs;
              WidgetsBinding.instance.addPostFrameCallback((_) => _markRead(docs));
              final visible = docs.where((d) {
                final h = d.data()['hidden_for'];
                return !(h is List && h.contains(widget.myTg));
              }).toList();
              if (visible.isEmpty) {
                return const Center(child: Text('Напишите первое сообщение', style: TextStyle(color: Colors.grey)));
              }
              return ListView.builder(
                reverse: true,
                itemCount: visible.length,
                itemBuilder: (context, i) => _bubble(visible[i]),
              );
            },
          ),
        ),
        _input(),
      ]),
    );
  }
}

class MediaPreviewScreen extends StatefulWidget {
  final List<PickedImage> items;
  const MediaPreviewScreen({super.key, required this.items});
  @override
  State<MediaPreviewScreen> createState() => _MediaPreviewScreenState();
}

class _MediaPreviewScreenState extends State<MediaPreviewScreen> {
  late final List<PickedImage> _items = List.of(widget.items);
  final _cap = TextEditingController();
  int _cur = 0;

  @override
  void dispose() {
    _cap.dispose();
    super.dispose();
  }

  void _removeCurrent() {
    if (_items.length == 1) {
      Navigator.pop(context);
      return;
    }
    setState(() {
      _items.removeAt(_cur);
      if (_cur >= _items.length) _cur = _items.length - 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Отправить (${_items.length})'),
        actions: [IconButton(icon: const Icon(Icons.delete_outline), onPressed: _removeCurrent)],
      ),
      body: Column(children: [
        Expanded(
          child: PageView.builder(
            itemCount: _items.length,
            onPageChanged: (i) => _cur = i,
            itemBuilder: (context, i) => Image.memory(_items[i].bytes, fit: BoxFit.contain),
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Expanded(child: TextField(controller: _cap, decoration: const InputDecoration(hintText: 'Подпись...'))),
              IconButton(
                icon: const Icon(Icons.send, color: accent),
                onPressed: () => Navigator.pop(context, {'images': List<PickedImage>.of(_items), 'caption': _cap.text.trim()}),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}

class MediaViewer extends StatelessWidget {
  final String data;
  final String heroTag;
  const MediaViewer({super.key, required this.data, required this.heroTag});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black),
      body: Center(
        child: Hero(tag: heroTag, child: InteractiveViewer(child: _MemImage(data: data, fit: BoxFit.contain))),
      ),
    );
  }
}
