import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

import 'config.dart';
import 'group_screens.dart';
import 'messaging.dart';
import 'profile_screen.dart';
import 'widgets.dart';

/// Фото хранится прямо в сообщении (base64). Документ Firestore ограничен ~1 МБ.
const _maxB64 = 900000;

class PickedImage {
  final Uint8List bytes;
  final String name;
  const PickedImage(this.bytes, this.name);
}

Widget _box(Widget child) => Container(width: 250, height: 250, color: Colors.black26, alignment: Alignment.center, child: child);

class _MemImage extends StatefulWidget {
  final String data;
  final double? width, height;
  final BoxFit fit;
  const _MemImage({required this.data, this.width, this.height, this.fit = BoxFit.cover});
  @override
  State<_MemImage> createState() => _MemImageState();
}

class _MemImageState extends State<_MemImage> {
  Uint8List? _bytes;

  @override
  void initState() {
    super.initState();
    try {
      _bytes = base64Decode(widget.data.split(',').last);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final b = _bytes;
    if (b == null) return _box(const Icon(Icons.broken_image, color: Colors.white38));
    return Image.memory(
      b,
      width: widget.width,
      height: widget.height,
      fit: widget.fit,
      gaplessPlayback: true,
      errorBuilder: (c, e, s) => _box(const Icon(Icons.broken_image, color: Colors.white38)),
    );
  }
}

class ChatScreen extends StatefulWidget {
  final String chatId, myTg, myName;
  const ChatScreen({super.key, required this.chatId, required this.myTg, required this.myName});

  /// Какой чат сейчас открыт (чтобы не показывать баннер о новом сообщении).
  static String? openChatId;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _msg = TextEditingController();
  final Set<String> _marked = {};
  late final Stream<DocumentSnapshot<Map<String, dynamic>>> _chatStream;
  late final Stream<QuerySnapshot<Map<String, dynamic>>> _stream;
  Stream<DocumentSnapshot<Map<String, dynamic>>>? _typingStream;
  Map<String, dynamic>? _reply;
  Map<String, dynamic> _chat = {};
  Timer? _tick;
  DateTime _lastTyping = DateTime.fromMillisecondsSinceEpoch(0);
  String? _lastMsgId;

  CollectionReference<Map<String, dynamic>> get _col => _chatRef.collection('messages');
  DocumentReference<Map<String, dynamic>> get _chatRef => FirebaseFirestore.instance.collection('chats').doc(widget.chatId);

  String get _type => (_chat['type'] as String?) ?? 'private';
  List<String> get _users => ((_chat['users'] as List?) ?? []).cast<String>();
  List<String> get _admins => ((_chat['admins'] as List?) ?? []).cast<String>();
  bool get _isAdmin => _admins.contains(widget.myTg);
  bool get _isMember => _users.contains(widget.myTg);
  bool get _canPost => _type == 'channel' ? _isAdmin : _isMember;
  String get _targetTg => _users.firstWhere((u) => u != widget.myTg, orElse: () => '');

  @override
  void initState() {
    super.initState();
    ChatScreen.openChatId = widget.chatId;
    _chatStream = _chatRef.snapshots();
    _stream = _col.orderBy('timestamp', descending: true).limit(60).snapshots();
    _msg.addListener(_onTyping);
    _tick = Timer.periodic(const Duration(seconds: 20), (_) {
      if (mounted) setState(() {});
    });
    resetUnread(widget.chatId, widget.myTg);
  }

  @override
  void dispose() {
    if (ChatScreen.openChatId == widget.chatId) ChatScreen.openChatId = null;
    _tick?.cancel();
    _msg.dispose();
    super.dispose();
  }

  void _onTyping() {
    if (_type != 'private' || _msg.text.trim().isEmpty) return;
    final now = DateTime.now();
    if (now.difference(_lastTyping).inSeconds < 3) return;
    _lastTyping = now;
    _chatRef.collection('typing').doc(widget.myTg).set({'ts': FieldValue.serverTimestamp()}).catchError((_) {});
  }

  Future<void> _post({String text = '', String? image, String? forwarded}) async {
    final reply = _reply;
    if (mounted) setState(() => _reply = null);
    await postMessage(
      chatId: widget.chatId,
      chat: _chat,
      myTg: widget.myTg,
      myName: widget.myName,
      text: text,
      image: image,
      reply: reply,
      forwarded: forwarded,
    );
  }

  Future<void> _sendText() async {
    final t = _msg.text.trim();
    if (t.isEmpty || !_canPost) return;
    _msg.clear();
    try {
      await _post(text: t);
    } catch (e) {
      if (mounted) snack(context, 'Не отправлено: $e');
    }
  }

  Future<void> _pickImages() async {
    final res = await ImagePicker().pickMultiImage(maxWidth: 1024, maxHeight: 1024, imageQuality: 55);
    if (res.isEmpty || !mounted) return;
    final items = <PickedImage>[];
    for (final x in res) {
      items.add(PickedImage(await x.readAsBytes(), x.name));
    }
    if (!mounted) return;
    final result = await Navigator.push<Map<String, dynamic>>(
      context,
      MaterialPageRoute(builder: (_) => MediaPreviewScreen(items: items)),
    );
    if (result == null) return;
    await _sendImages(result['images'] as List<PickedImage>, result['caption'] as String);
  }

  Future<void> _sendImages(List<PickedImage> imgs, String caption) async {
    var skipped = 0;
    for (final im in imgs) {
      final b64 = base64Encode(im.bytes);
      if (b64.length > _maxB64) {
        skipped++;
        continue;
      }
      try {
        await _post(text: caption, image: 'data:image/jpeg;base64,$b64');
        caption = '';
      } catch (e) {
        if (mounted) snack(context, 'Не отправлено: $e');
      }
    }
    if (skipped > 0 && mounted) snack(context, 'Слишком тяжёлых фото пропущено: $skipped');
  }

  Future<void> _deleteMsg(String id, bool forAll) async {
    try {
      if (forAll) {
        await _col.doc(id).delete();
      } else {
        await _col.doc(id).update({'hidden_for': FieldValue.arrayUnion([widget.myTg])});
      }
    } catch (e) {
      if (mounted) snack(context, 'Ошибка: $e');
    }
  }

  void _markRead(List<JsonDoc> docs) {
    if (_type != 'private') return;
    final unread = docs.where((d) {
      final m = d.data();
      return m['sender_tg'] == _targetTg && m['is_read'] != true && !_marked.contains(d.id);
    }).toList();
    if (unread.isEmpty) return;
    final batch = FirebaseFirestore.instance.batch();
    for (final d in unread) {
      _marked.add(d.id);
      batch.update(d.reference, {'is_read': true});
    }
    batch.commit().catchError((_) {});
  }

  void _startReply(JsonDoc doc) {
    final m = doc.data();
    final text = (m['text'] as String?) ?? '';
    final img = m['image'] as String?;
    setState(() {
      _reply = {
        'id': doc.id,
        'name': (m['sender_name'] as String?) ?? '',
        'text': text.isNotEmpty ? (text.length > 80 ? text.substring(0, 80) : text) : (img != null ? '📷 Фото' : ''),
      };
    });
  }

  Future<void> _forward(JsonDoc doc) async {
    final m = doc.data();
    final target = await showForwardPicker(context, myTg: widget.myTg);
    if (target == null) return;
    final from = (m['forwarded'] as String?) ?? ((m['sender_name'] as String?) ?? '');
    try {
      await postMessage(
        chatId: target.id,
        chat: target.data,
        myTg: widget.myTg,
        myName: widget.myName,
        text: (m['text'] as String?) ?? '',
        image: m['image'] as String?,
        forwarded: from.isEmpty ? 'пересланное сообщение' : from,
      );
      if (mounted) snack(context, 'Переслано');
    } catch (e) {
      if (mounted) snack(context, 'Не удалось переслать: $e');
    }
  }

  void _showMenu(JsonDoc doc) {
    final m = doc.data();
    final isMine = m['sender_tg'] == widget.myTg;
    final text = (m['text'] as String?) ?? '';
    final canDeleteAll = _type == 'private' ? isMine : (isMine || _isAdmin);
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (_canPost)
            ListTile(
              leading: const Icon(Icons.reply),
              title: const Text('Ответить'),
              onTap: () {
                Navigator.pop(ctx);
                _startReply(doc);
              },
            ),
          if (text.isNotEmpty)
            ListTile(
              leading: const Icon(Icons.copy),
              title: const Text('Копировать'),
              onTap: () {
                Navigator.pop(ctx);
                Clipboard.setData(ClipboardData(text: text));
                snack(context, 'Скопировано');
              },
            ),
          ListTile(
            leading: const Icon(Icons.forward),
            title: const Text('Переслать'),
            onTap: () {
              Navigator.pop(ctx);
              _forward(doc);
            },
          ),
          ListTile(
            leading: const Icon(Icons.visibility_off),
            title: const Text('Удалить у меня'),
            onTap: () {
              Navigator.pop(ctx);
              _deleteMsg(doc.id, false);
            },
          ),
          if (canDeleteAll)
            ListTile(
              leading: const Icon(Icons.delete_forever, color: Colors.red),
              title: const Text('Удалить у всех', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.pop(ctx);
                _deleteMsg(doc.id, true);
              },
            ),
        ]),
      ),
    );
  }

  Widget _quote(Map<String, dynamic> r) => Container(
        width: double.infinity,
        margin: const EdgeInsets.fromLTRB(4, 2, 4, 4),
        padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
        decoration: const BoxDecoration(color: Colors.black26, border: Border(left: BorderSide(color: accent, width: 3))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          if (((r['name'] as String?) ?? '').isNotEmpty)
            Text(r['name'] as String, style: const TextStyle(color: accent, fontWeight: FontWeight.bold, fontSize: 12)),
          Text((r['text'] as String?) ?? '', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
        ]),
      );

  Widget _bubble(JsonDoc doc) {
    final m = doc.data();
    final isMe = m['sender_tg'] == widget.myTg;
    final text = (m['text'] as String?) ?? '';
    final img = m['image'] as String?;
    final ts = m['timestamp'];
    final reply = m['reply'] as Map<String, dynamic>?;
    final fwd = m['forwarded'] as String?;
    final senderName = (m['sender_name'] as String?) ?? '';
    final channel = _type == 'channel';
    final right = isMe && !channel;

    Widget? media;
    if (img != null && img.isNotEmpty) {
      media = GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MediaViewer(data: img, heroTag: doc.id))),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Hero(tag: doc.id, child: _MemImage(data: img, width: 250, height: 250)),
        ),
      );
    }

    return Align(
      key: ValueKey(doc.id),
      alignment: right ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () => _showMenu(doc),
        child: Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
          margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(color: right ? bubbleMe : bubbleOther, borderRadius: BorderRadius.circular(14)),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (_type == 'group' && !isMe && senderName.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
                child: Text(senderName, style: const TextStyle(color: accent, fontWeight: FontWeight.bold, fontSize: 12)),
              ),
            if (fwd != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
                child: Text('Переслано от $fwd', style: const TextStyle(fontStyle: FontStyle.italic, color: Colors.white60, fontSize: 11)),
              ),
            if (reply != null) _quote(reply),
            if (media != null) media,
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
              child: Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
                if (text.isNotEmpty) Flexible(child: Text(text)),
                if (text.isNotEmpty) const SizedBox(width: 10),
                Text(ts is Timestamp ? hhmm(ts.toDate()) : '--:--', style: const TextStyle(fontSize: 10, color: Colors.white54)),
                if (isMe && _type == 'private') ...[
                  const SizedBox(width: 4),
                  Icon(m['is_read'] == true ? Icons.done_all : Icons.done, size: 14, color: accent),
                ],
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _bar(Widget child) => SafeArea(
        top: false,
        child: Container(color: surfaceDark, width: double.infinity, padding: const EdgeInsets.all(12), alignment: Alignment.center, child: child),
      );

  Widget _input() {
    final r = _reply;
    return SafeArea(
      top: false,
      child: Container(
        color: surfaceDark,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (r != null)
            Container(
              width: double.infinity,
              color: Colors.black26,
              padding: const EdgeInsets.fromLTRB(12, 6, 4, 6),
              child: Row(children: [
                const Icon(Icons.reply, color: accent, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(((r['name'] as String?) ?? '').isEmpty ? 'Ответ' : r['name'] as String, style: const TextStyle(color: accent, fontWeight: FontWeight.bold, fontSize: 12)),
                    Text((r['text'] as String?) ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                  ]),
                ),
                IconButton(icon: const Icon(Icons.close, size: 18), onPressed: () => setState(() => _reply = null)),
              ]),
            ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              IconButton(icon: const Icon(Icons.image), onPressed: _pickImages),
              Expanded(
                child: TextField(
                  controller: _msg,
                  minLines: 1,
                  maxLines: 5,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: const InputDecoration(border: InputBorder.none, hintText: 'Сообщение'),
                ),
              ),
              IconButton(icon: const Icon(Icons.send, color: accent), onPressed: _sendText),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _bottom() {
    if (_type == 'channel' && !_isAdmin) {
      if (!_isMember) {
        return _bar(ElevatedButton(
          onPressed: () async {
            try {
              await _chatRef.update({'users': FieldValue.arrayUnion([widget.myTg])});
            } catch (e) {
              if (mounted) snack(context, 'Ошибка: $e');
            }
          },
          child: const Text('ПОДПИСАТЬСЯ'),
        ));
      }
      return _bar(const Text('Писать в канал могут только администраторы', style: TextStyle(color: Colors.grey)));
    }
    if (!_isMember) return _bar(const Text('Вы больше не участник этого чата', style: TextStyle(color: Colors.grey)));
    return _input();
  }

  Widget _statusLine(Map<String, dynamic>? d, String t) {
    _typingStream ??= _chatRef.collection('typing').doc(t).snapshots();
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: _typingStream,
      builder: (context, s) {
        final ts = s.data?.data()?['ts'];
        final typing = ts is Timestamp && DateTime.now().difference(ts.toDate()).inSeconds < 6;
        return Text(
          typing ? 'печатает…' : lastSeenText(d?['last_seen']),
          style: TextStyle(fontSize: 12, color: typing ? accent : Colors.grey),
        );
      },
    );
  }

  Widget _title(Map<String, dynamic> chat) {
    if (_type == 'private') {
      final t = _targetTg;
      return UserLive(
        tg: t,
        builder: (context, d, uid) => InkWell(
          onTap: uid.isEmpty ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileScreen(uid: uid, isMe: false))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(userName(d, t), style: const TextStyle(fontSize: 18)),
            _statusLine(d, t),
          ]),
        ),
      );
    }
    final title = (chat['title'] as String?) ?? 'Чат';
    return InkWell(
      onTap: _openInfo,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisSize: MainAxisSize.min, children: [
          Flexible(child: Text(title, style: const TextStyle(fontSize: 18), overflow: TextOverflow.ellipsis)),
          if (chat['verified'] == true) ...[const SizedBox(width: 4), const VerifiedBadge()],
        ]),
        Text(
          _type == 'channel' ? 'Подписчиков: ${_users.length}' : 'Участников: ${_users.length}',
          style: const TextStyle(fontSize: 12, color: Colors.grey),
        ),
      ]),
    );
  }

  void _openInfo() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ChatInfoScreen(chatId: widget.chatId, myTg: widget.myTg)));
  }

  Widget _messages() {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: _stream,
      builder: (context, snap) {
        if (snap.hasError) return Center(child: Text('Ошибка: ${snap.error}'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snap.data!.docs;
        WidgetsBinding.instance.addPostFrameCallback((_) => _markRead(docs));
        if (docs.isNotEmpty && docs.first.id != _lastMsgId) {
          _lastMsgId = docs.first.id;
          if (docs.first.data()['sender_tg'] != widget.myTg) {
            WidgetsBinding.instance.addPostFrameCallback((_) => resetUnread(widget.chatId, widget.myTg));
          }
        }
        final visible = docs.where((d) {
          final h = d.data()['hidden_for'];
          return !(h is List && h.contains(widget.myTg));
        }).toList();
        if (visible.isEmpty) {
          return const Center(child: Text('Сообщений пока нет', style: TextStyle(color: Colors.grey)));
        }
        return ListView.builder(
          reverse: true,
          itemCount: visible.length,
          itemBuilder: (context, i) => _bubble(visible[i]),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: _chatStream,
      builder: (context, cs) {
        if (cs.hasError) return Scaffold(appBar: AppBar(), body: Center(child: Text('Ошибка: ${cs.error}')));
        if (!cs.hasData) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
        final chat = cs.data!.data();
        if (chat == null) return Scaffold(appBar: AppBar(), body: const Center(child: Text('Чат удалён')));
        _chat = chat;
        return Scaffold(
          appBar: AppBar(
            title: _title(chat),
            actions: [if (_type != 'private') IconButton(icon: const Icon(Icons.info_outline), onPressed: _openInfo)],
          ),
          body: Column(children: [Expanded(child: _messages()), _bottom()]),
        );
      },
    );
  }
}

class MediaPreviewScreen extends StatefulWidget {
  final List<PickedImage> items;
  const MediaPreviewScreen({super.key, required this.items});
  @override
  State<MediaPreviewScreen> createState() => _MediaPreviewScreenState();
}

class _MediaPreviewScreenState extends State<MediaPreviewScreen> {
  late final List<PickedImage> _items = List.of(widget.items);
  final _cap = TextEditingController();
  int _cur = 0;

  @override
  void dispose() {
    _cap.dispose();
    super.dispose();
  }

  void _removeCurrent() {
    if (_items.length == 1) {
      Navigator.pop(context);
      return;
    }
    setState(() {
      _items.removeAt(_cur);
      if (_cur >= _items.length) _cur = _items.length - 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Отправить (${_items.length})'),
        actions: [IconButton(icon: const Icon(Icons.delete_outline), onPressed: _removeCurrent)],
      ),
      body: Column(children: [
        Expanded(
          child: PageView.builder(
            itemCount: _items.length,
            onPageChanged: (i) => _cur = i,
            itemBuilder: (context, i) => Image.memory(_items[i].bytes, fit: BoxFit.contain),
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Expanded(child: TextField(controller: _cap, decoration: const InputDecoration(hintText: 'Подпись...'))),
              IconButton(
                icon: const Icon(Icons.send, color: accent),
                onPressed: () => Navigator.pop(context, {'images': List<PickedImage>.of(_items), 'caption': _cap.text.trim()}),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}

class MediaViewer extends StatelessWidget {
  final String data;
  final String heroTag;
  const MediaViewer({super.key, required this.data, required this.heroTag});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black),
      body: Center(
        child: Hero(tag: heroTag, child: InteractiveViewer(child: _MemImage(data: data, fit: BoxFit.contain))),
      ),
    );
  }
}
