import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dio/dio.dart' as dio;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

import 'config.dart';
import 'profile_screen.dart';
import 'widgets.dart';

class MediaItem {
  final XFile file;
  final bool isVideo;
  const MediaItem(this.file, this.isVideo);
}

Widget _box(Widget child) => Container(width: 250, height: 250, color: Colors.black26, alignment: Alignment.center, child: child);

class PrivateChatScreen extends StatefulWidget {
  final String chatId, myTg, targetTg, targetName, targetUid;
  const PrivateChatScreen({
    super.key,
    required this.chatId,
    required this.myTg,
    required this.targetTg,
    required this.targetName,
    required this.targetUid,
  });
  @override
  State<PrivateChatScreen> createState() => _PrivateChatScreenState();
}

class _PrivateChatScreenState extends State<PrivateChatScreen> {
  final _msg = TextEditingController();
  final _http = dio.Dio(dio.BaseOptions(
    connectTimeout: const Duration(seconds: 15),
    sendTimeout: const Duration(minutes: 10),
    receiveTimeout: const Duration(minutes: 2),
  ));
  final Set<String> _marked = {};
  late final Stream<QuerySnapshot<Map<String, dynamic>>> _stream;

  CollectionReference<Map<String, dynamic>> get _col => FirebaseFirestore.instance.collection('chats').doc(widget.chatId).collection('messages');
  DocumentReference<Map<String, dynamic>> get _chatRef => FirebaseFirestore.instance.collection('chats').doc(widget.chatId);

  @override
  void initState() {
    super.initState();
    _stream = _col.orderBy('timestamp', descending: true).limit(200).snapshots();
  }

  @override
  void dispose() {
    _msg.dispose();
    _http.close();
    super.dispose();
  }

  Future<void> _touchChat(String last) async {
    try {
      await _chatRef.update({'last_time': FieldValue.serverTimestamp(), 'last_msg': last});
    } catch (_) {}
  }

  Future<void> _sendText() async {
    final t = _msg.text.trim();
    if (t.isEmpty) return;
    _msg.clear();
    try {
      await _col.add({
        'text': t,
        'sender_tg': widget.myTg,
        'timestamp': FieldValue.serverTimestamp(),
        'is_read': false,
        'hidden_for': <String>[],
      });
      await _touchChat(t);
    } catch (e) {
      if (mounted) snack(context, 'Не отправлено: $e');
    }
  }

  Future<void> _pickMedia() async {
    final res = await ImagePicker().pickMultipleMedia();
    if (res.isEmpty || !mounted) return;
    final items = res.map((x) => MediaItem(x, isVideoPath(x.path) || (x.mimeType ?? '').startsWith('video/'))).toList();
    final result = await Navigator.push<Map<String, dynamic>>(
      context,
      MaterialPageRoute(builder: (_) => MediaPreviewScreen(items: items)),
    );
    if (result == null) return;
    _upload(result['media'] as List<MediaItem>, result['caption'] as String);
  }

  Future<void> _upload(List<MediaItem> media, String caption) async {
    for (final item in media) {
      final DocumentReference<Map<String, dynamic>> ref;
      try {
        ref = await _col.add({
          'sender_tg': widget.myTg,
          'timestamp': FieldValue.serverTimestamp(),
          'is_loading': true,
          'is_video': item.isVideo,
          'local_path': item.file.path,
          'text': caption,
          'is_read': false,
          'hidden_for': <String>[],
        });
      } catch (e) {
        if (mounted) snack(context, 'Не отправлено: $e');
        continue;
      }
      caption = '';
      _touchChat(item.isVideo ? '🎬 Видео' : '📷 Фото');
      try {
        final form = dio.FormData.fromMap({
          'file': await dio.MultipartFile.fromFile(item.file.path, filename: item.file.name),
          'is_video': item.isVideo.toString(),
        });
        final resp = await _http.post('$backendUrl/upload', data: form);
        var url = (resp.data is Map ? resp.data['url'] : null) as String?;
        if (url == null || url.isEmpty) throw 'сервер не вернул ссылку';
        if (!url.startsWith('http')) url = '$backendUrl${url.startsWith('/') ? '' : '/'}$url';
        await ref.update({'media_url': url, 'is_loading': false, 'local_path': FieldValue.delete()});
      } catch (e) {
        try {
          await ref.update({'is_loading': false, 'failed': true});
        } catch (_) {}
        if (mounted) snack(context, 'Файл не отправлен: $e');
      }
    }
  }

  Future<void> _deleteMsg(String id, bool forAll) async {
    try {
      if (forAll) {
        await _col.doc(id).delete();
      } else {
        await _col.doc(id).update({'hidden_for': FieldValue.arrayUnion([widget.myTg])});
      }
    } catch (e) {
      if (mounted) snack(context, 'Ошибка: $e');
    }
  }

  void _markRead(List<JsonDoc> docs) {
    final unread = docs.where((d) {
      final m = d.data();
      return m['sender_tg'] == widget.targetTg && m['is_read'] != true && !_marked.contains(d.id);
    }).toList();
    if (unread.isEmpty) return;
    final batch = FirebaseFirestore.instance.batch();
    for (final d in unread) {
      _marked.add(d.id);
      batch.update(d.reference, {'is_read': true});
    }
    batch.commit().catchError((_) {});
  }

  void _showMenu(String id, bool mine) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.visibility_off),
            title: const Text('Удалить у меня'),
            onTap: () {
              Navigator.pop(ctx);
              _deleteMsg(id, false);
            },
          ),
          if (mine)
            ListTile(
              leading: const Icon(Icons.delete_forever, color: Colors.red),
              title: const Text('Удалить у обоих', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.pop(ctx);
                _deleteMsg(id, true);
              },
            ),
        ]),
      ),
    );
  }

  Widget _pending(bool isMe, String? local, bool isVideo, bool failed) {
    final Widget base;
    if (isMe && local != null && !isVideo) {
      base = Image.file(
        File(local),
        width: 250,
        height: 250,
        fit: BoxFit.cover,
        errorBuilder: (c, e, s) => _box(const Icon(Icons.image, size: 48, color: Colors.white38)),
      );
    } else {
      base = _box(Icon(isVideo ? Icons.videocam : Icons.image, size: 48, color: Colors.white38));
    }
    return Stack(alignment: Alignment.center, children: [
      base,
      failed ? const Icon(Icons.error_outline, color: Colors.redAccent, size: 40) : const CircularProgressIndicator(),
    ]);
  }

  Widget _bubble(JsonDoc doc) {
    final m = doc.data();
    final isMe = m['sender_tg'] == widget.myTg;
    final text = (m['text'] as String?) ?? '';
    final isVideo = m['is_video'] == true;
    final url = m['media_url'] as String?;
    final loading = m['is_loading'] == true;
    final failed = m['failed'] == true;
    final ts = m['timestamp'];

    Widget? media;
    if (url != null) {
      media = GestureDetector(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => MediaViewer(url: url, isVideo: isVideo, heroTag: doc.id)),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: isVideo
              ? _box(const Icon(Icons.play_circle_fill, size: 56, color: Colors.white70))
              : Hero(
                  tag: doc.id,
                  child: Image.network(
                    url,
                    width: 250,
                    height: 250,
                    fit: BoxFit.cover,
                    loadingBuilder: (c, child, p) => p == null ? child : _box(const CircularProgressIndicator()),
                    errorBuilder: (c, e, s) => _box(const Icon(Icons.broken_image, color: Colors.white38)),
                  ),
                ),
        ),
      );
    } else if (loading || failed) {
      media = ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: _pending(isMe, m['local_path'] as String?, isVideo, failed),
      );
    }

    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () => _showMenu(doc.id, isMe),
        child: Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
          margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(color: isMe ? bubbleMe : bubbleOther, borderRadius: BorderRadius.circular(14)),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (media != null) media,
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
              child: Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
                if (text.isNotEmpty) Flexible(child: Text(text)),
                if (text.isNotEmpty) const SizedBox(width: 10),
                Text(ts is Timestamp ? hhmm(ts.toDate()) : '--:--', style: const TextStyle(fontSize: 10, color: Colors.white54)),
                if (isMe) ...[
                  const SizedBox(width: 4),
                  Icon(m['is_read'] == true ? Icons.done_all : Icons.done, size: 14, color: emberOrange),
                ],
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _input() {
    return SafeArea(
      top: false,
      child: Container(
        color: surfaceDark,
        padding: const EdgeInsets.all(8),
        child: Row(children: [
          IconButton(icon: const Icon(Icons.attach_file), onPressed: _pickMedia),
          Expanded(
            child: TextField(
              controller: _msg,
              minLines: 1,
              maxLines: 5,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(border: InputBorder.none, hintText: 'Сообщение'),
            ),
          ),
          IconButton(icon: const Icon(Icons.send, color: emberOrange), onPressed: _sendText),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: InkWell(
          onTap: widget.targetUid.isEmpty
              ? null
              : () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileScreen(uid: widget.targetUid, isMe: false))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.targetName, style: const TextStyle(fontSize: 18)),
            Text('@${widget.targetTg}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ]),
        ),
      ),
      body: Column(children: [
        Expanded(
          child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: _stream,
            builder: (context, snap) {
              if (snap.hasError) return Center(child: Text('Ошибка: ${snap.error}'));
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final docs = snap.data!.docs;
              WidgetsBinding.instance.addPostFrameCallback((_) => _markRead(docs));
              final visible = docs.where((d) {
                final h = d.data()['hidden_for'];
                return !(h is List && h.contains(widget.myTg));
              }).toList();
              if (visible.isEmpty) {
                return const Center(child: Text('Напишите первое сообщение', style: TextStyle(color: Colors.grey)));
              }
              return ListView.builder(
                reverse: true,
                itemCount: visible.length,
                itemBuilder: (context, i) => _bubble(visible[i]),
              );
            },
          ),
        ),
        _input(),
      ]),
    );
  }
}

class MediaPreviewScreen extends StatefulWidget {
  final List<MediaItem> items;
  const MediaPreviewScreen({super.key, required this.items});
  @override
  State<MediaPreviewScreen> createState() => _MediaPreviewScreenState();
}

class _MediaPreviewScreenState extends State<MediaPreviewScreen> {
  late final List<MediaItem> _items = List.of(widget.items);
  final _cap = TextEditingController();
  int _cur = 0;

  @override
  void dispose() {
    _cap.dispose();
    super.dispose();
  }

  void _removeCurrent() {
    if (_items.length == 1) {
      Navigator.pop(context);
      return;
    }
    setState(() {
      _items.removeAt(_cur);
      if (_cur >= _items.length) _cur = _items.length - 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Отправить (${_items.length})'),
        actions: [IconButton(icon: const Icon(Icons.delete_outline), onPressed: _removeCurrent)],
      ),
      body: Column(children: [
        Expanded(
          child: PageView.builder(
            itemCount: _items.length,
            onPageChanged: (i) => _cur = i,
            itemBuilder: (context, i) {
              final it = _items[i];
              if (it.isVideo) {
                return Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.videocam, size: 80, color: Colors.white54),
                    const SizedBox(height: 10),
                    Text(it.file.name),
                  ]),
                );
              }
              return Image.file(File(it.file.path), fit: BoxFit.contain);
            },
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Expanded(child: TextField(controller: _cap, decoration: const InputDecoration(hintText: 'Подпись...'))),
              IconButton(
                icon: const Icon(Icons.send, color: emberOrange),
                onPressed: () => Navigator.pop(context, {'media': List<MediaItem>.of(_items), 'caption': _cap.text.trim()}),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}

class MediaViewer extends StatefulWidget {
  final String url;
  final bool isVideo;
  final String heroTag;
  const MediaViewer({super.key, required this.url, required this.isVideo, required this.heroTag});
  @override
  State<MediaViewer> createState() => _MediaViewerState();
}

class _MediaViewerState extends State<MediaViewer> {
  VideoPlayerController? _v;
  bool _error = false;

  @override
  void initState() {
    super.initState();
    if (widget.isVideo) {
      final c = VideoPlayerController.networkUrl(Uri.parse(widget.url));
      _v = c;
      c.initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        c.play();
      }).catchError((_) {
        if (mounted) setState(() => _error = true);
      });
    }
  }

  @override
  void dispose() {
    _v?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final v = _v;
    final Widget content;
    if (!widget.isVideo) {
      content = Hero(tag: widget.heroTag, child: InteractiveViewer(child: Image.network(widget.url)));
    } else if (_error) {
      content = const Text('Не удалось воспроизвести видео');
    } else if (v == null || !v.value.isInitialized) {
      content = const CircularProgressIndicator();
    } else {
      content = ValueListenableBuilder<VideoPlayerValue>(
        valueListenable: v,
        builder: (context, val, _) => GestureDetector(
          onTap: () => val.isPlaying ? v.pause() : v.play(),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Stack(alignment: Alignment.center, children: [
              AspectRatio(aspectRatio: val.aspectRatio, child: VideoPlayer(v)),
              if (!val.isPlaying) const Icon(Icons.play_circle_fill, size: 64, color: Colors.white70),
            ]),
            VideoProgressIndicator(v, allowScrubbing: true, padding: const EdgeInsets.all(12)),
          ]),
        ),
      );
    }
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black),
      body: Center(child: content),
    );
  }
}
