import 'package:cloud_firestore/cloud_firestore.dart';

const emberChatId = 'ember';

String chatPreview(String text, String? image) {
  if (image != null && image.isNotEmpty) return text.isEmpty ? '📷 Фото' : '📷 $text';
  return text;
}

/// Отправка сообщения в любой чат (личный, группа, канал). Увеличивает счётчики непрочитанных.
Future<void> postMessage({
  required String chatId,
  required Map<String, dynamic> chat,
  required String myTg,
  required String myName,
  String text = '',
  String? image,
  Map<String, dynamic>? reply,
  String? forwarded,
}) async {
  final ref = FirebaseFirestore.instance.collection('chats').doc(chatId);
  await ref.collection('messages').add({
    'sender_tg': myTg,
    'sender_name': myName,
    'timestamp': FieldValue.serverTimestamp(),
    'text': text,
    if (image != null) 'image': image,
    if (reply != null) 'reply': reply,
    if (forwarded != null) 'forwarded': forwarded,
    'is_read': false,
    'hidden_for': <String>[],
  });
  final others = ((chat['users'] as List?) ?? []).cast<String>().where((u) => u != myTg);
  try {
    await ref.update({
      'last_time': FieldValue.serverTimestamp(),
      'last_msg': chatPreview(text, image),
      for (final u in others) 'unread.$u': FieldValue.increment(1),
    });
  } catch (_) {}
}

Future<void> resetUnread(String chatId, String myTg) async {
  try {
    await FirebaseFirestore.instance.collection('chats').doc(chatId).update({'unread.$myTg': 0});
  } catch (_) {}
}

/// Канал «Ember» есть у всех: его создаёт пользователь develop, остальные подписываются автоматически.
Future<void> ensureEmberChannel(String myTg, String myUsername) async {
  final ref = FirebaseFirestore.instance.collection('chats').doc(emberChatId);
  try {
    final snap = await ref.get();
    if (!snap.exists) {
      if (myUsername == 'develop') {
        await ref.set({
          'type': 'channel',
          'title': 'Ember',
          'verified': true,
          'admins': [myTg],
          'users': [myTg],
          'last_time': FieldValue.serverTimestamp(),
          'last_msg': 'Добро пожаловать в Ember!',
        });
      }
      return;
    }
    final users = ((snap.data()?['users'] as List?) ?? []).cast<String>();
    if (!users.contains(myTg)) {
      await ref.update({'users': FieldValue.arrayUnion([myTg])});
    }
  } catch (_) {}
}

/// Полное удаление чата: сообщения, запись в реестре имён (для каналов) и сам чат.
Future<void> deleteChatCompletely(String chatId, {String? handle}) async {
  final db = FirebaseFirestore.instance;
  if (handle != null && handle.isNotEmpty) {
    try {
      await db.collection('usernames').doc(handle).delete();
    } catch (_) {}
  }
  final msgs = db.collection('chats').doc(chatId).collection('messages');
  while (true) {
    final snap = await msgs.limit(400).get();
    if (snap.docs.isEmpty) break;
    final batch = db.batch();
    for (final d in snap.docs) {
      batch.delete(d.reference);
    }
    await batch.commit();
  }
  await db.collection('chats').doc(chatId).delete();
}
