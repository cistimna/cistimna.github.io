import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'widgets.dart';

class ProfileScreen extends StatefulWidget {
  final String uid;
  final bool isMe;
  const ProfileScreen({super.key, required this.uid, required this.isMe});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  DocumentReference<Map<String, dynamic>> get _ref => FirebaseFirestore.instance.collection('users').doc(widget.uid);

  Future<void> _changePhoto() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 256, maxHeight: 256, imageQuality: 70);
    if (picked == null) return;
    try {
      final bytes = await picked.readAsBytes();
      await _ref.update({'photo_url': 'data:image/jpeg;base64,${base64Encode(bytes)}'});
      if (mounted) snack(context, 'Аватарка обновлена!');
    } catch (e) {
      if (mounted) snack(context, 'Ошибка: $e');
    }
  }

  void _changeName(String current) {
    final ctrl = TextEditingController(text: current);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Изменить имя'),
        content: TextField(controller: ctrl, autofocus: true, decoration: const InputDecoration(hintText: 'Новое имя')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ОТМЕНА')),
          TextButton(
            onPressed: () async {
              final n = ctrl.text.trim();
              if (n.isEmpty) return;
              try {
                await _ref.update({'display_name': n});
                if (ctx.mounted) Navigator.pop(ctx);
                if (mounted) snack(context, 'Имя обновлено!');
              } catch (e) {
                if (ctx.mounted) snack(ctx, 'Ошибка: $e');
              }
            },
            child: const Text('СОХРАНИТЬ'),
          ),
        ],
      ),
    );
  }

  Future<void> _logout() async {
    final nav = Navigator.of(context);
    nav.popUntil((r) => r.isFirst);
    await FirebaseAuth.instance.signOut();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: _ref.snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return Scaffold(appBar: AppBar(), body: Center(child: Text('Ошибка: ${snap.error}')));
        if (!snap.hasData) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        final d = snap.data!.data();
        if (d == null) return Scaffold(appBar: AppBar(), body: const Center(child: Text('Профиль не найден')));
        final name = (d['display_name'] as String?) ?? '';

        return Scaffold(
          appBar: AppBar(title: const Text('Профиль')),
          body: Center(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Stack(alignment: Alignment.bottomRight, children: [
                UserAvatar(url: d['photo_url'] as String?, name: name, radius: 60),
                if (widget.isMe)
                  GestureDetector(
                    onTap: _changePhoto,
                    child: const CircleAvatar(radius: 18, child: Icon(Icons.camera_alt, size: 18)),
                  ),
              ]),
              const SizedBox(height: 20),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                if (widget.isMe) IconButton(icon: const Icon(Icons.edit, size: 20, color: Colors.grey), onPressed: () => _changeName(name)),
              ]),
              Text('@${d['tg_username']}', style: const TextStyle(color: Colors.grey)),
              const SizedBox(height: 40),
              if (widget.isMe)
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red.withValues(alpha: 0.2)),
                  onPressed: _logout,
                  child: const Text('ВЫЙТИ', style: TextStyle(color: Colors.redAccent)),
                ),
            ]),
          ),
        );
      },
    );
  }
}
