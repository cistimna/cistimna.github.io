import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

import 'accounts.dart';
import 'config.dart';
import 'widgets.dart';

class ProfileScreen extends StatefulWidget {
  final String uid;
  final bool isMe;
  const ProfileScreen({super.key, required this.uid, required this.isMe});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  DocumentReference<Map<String, dynamic>> get _ref => FirebaseFirestore.instance.collection('users').doc(widget.uid);

  Future<void> _changePhoto() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 400, maxHeight: 400, imageQuality: 70);
    if (picked == null) return;
    try {
      final bytes = await picked.readAsBytes();
      await _ref.update({'photo_url': 'data:image/jpeg;base64,${base64Encode(bytes)}'});
      if (mounted) snack(context, 'Фото обновлено');
    } catch (e) {
      if (mounted) snack(context, 'Ошибка: $e');
    }
  }

  void _editField(String title, String key, String current, {int maxLen = 40, int lines = 1}) {
    final ctrl = TextEditingController(text: current);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(controller: ctrl, autofocus: true, maxLength: maxLen, minLines: 1, maxLines: lines),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ОТМЕНА')),
          TextButton(
            onPressed: () async {
              final v = ctrl.text.trim();
              if (key == 'display_name' && v.isEmpty) return;
              try {
                await _ref.update({key: v});
                if (ctx.mounted) Navigator.pop(ctx);
              } catch (e) {
                if (ctx.mounted) snack(ctx, 'Ошибка: $e');
              }
            },
            child: const Text('СОХРАНИТЬ'),
          ),
        ],
      ),
    );
  }

  void _editMenu(String name, String bio) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.photo_camera_outlined),
            title: const Text('Изменить фото'),
            onTap: () {
              Navigator.pop(ctx);
              _changePhoto();
            },
          ),
          ListTile(
            leading: const Icon(Icons.badge_outlined),
            title: const Text('Изменить имя'),
            onTap: () {
              Navigator.pop(ctx);
              _editField('Имя', 'display_name', name);
            },
          ),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('Изменить «О себе»'),
            onTap: () {
              Navigator.pop(ctx);
              _editField('О себе', 'bio', bio, maxLen: 120, lines: 3);
            },
          ),
        ]),
      ),
    );
  }

  Widget _card(List<Widget> children) => Material(
        color: bubbleOther,
        borderRadius: BorderRadius.circular(16),
        clipBehavior: Clip.antiAlias,
        child: Column(children: children),
      );

  Widget _row(IconData icon, String value, String label, {VoidCallback? onTap}) => ListTile(
        leading: Icon(icon, color: Colors.grey),
        title: Text(value),
        subtitle: Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
        onTap: onTap,
      );

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: _ref.snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return Scaffold(appBar: AppBar(), body: Center(child: Text('Ошибка: ${snap.error}')));
        if (!snap.hasData) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        final d = snap.data!.data();
        if (d == null) return Scaffold(appBar: AppBar(), body: const Center(child: Text('Профиль не найден')));
        final name = (d['display_name'] as String?) ?? '';
        final bio = (d['bio'] as String?) ?? '';
        final tg = (d['tg_username'] as String?) ?? '';
        final un = uname(d);

        return Scaffold(
          appBar: AppBar(
            backgroundColor: bgDark,
            actions: [
              if (widget.isMe) IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () => _editMenu(name, bio)),
            ],
          ),
          body: ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), children: [
            const SizedBox(height: 8),
            Center(
              child: GestureDetector(
                onTap: widget.isMe ? _changePhoto : null,
                child: UserAvatar(url: d['photo_url'] as String?, name: name, radius: 64),
              ),
            ),
            const SizedBox(height: 16),
            Center(child: Text(name, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
            const SizedBox(height: 4),
            Center(child: Text('@$un', style: const TextStyle(fontSize: 16, color: accent))),
            const SizedBox(height: 28),
            _card([
              _row(
                Icons.info_outline,
                bio.isEmpty ? 'Не указано' : bio,
                'О себе',
                onTap: widget.isMe ? () => _editField('О себе', 'bio', bio, maxLen: 120, lines: 3) : null,
              ),
              _row(
                Icons.alternate_email,
                '@$un',
                'Имя пользователя',
                onTap: widget.isMe
                    ? () => showUsernameDialog(context, uid: widget.uid, tg: tg, current: un)
                    : () {
                        Clipboard.setData(ClipboardData(text: '@$un'));
                        snack(context, 'Скопировано');
                      },
              ),
            ]),
          ]),
        );
      },
    );
  }
}
