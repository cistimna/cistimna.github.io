import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'widgets.dart';

/// Аккаунты, сохранённые на устройстве (максимум 2). Хранятся только внутренние id.
class AccountStore {
  static const _k = 'accounts_v1';
  static const maxAccounts = 2;

  static Future<List<String>> load() async {
    final p = await SharedPreferences.getInstance();
    return List<String>.of(p.getStringList(_k) ?? const []);
  }

  static Future<bool> add(String tg) async {
    final p = await SharedPreferences.getInstance();
    final l = List<String>.of(p.getStringList(_k) ?? const []);
    if (l.contains(tg)) return true;
    if (l.length >= maxAccounts) return false;
    l.add(tg);
    await p.setStringList(_k, l);
    return true;
  }

  static Future<void> remove(String tg) async {
    final p = await SharedPreferences.getInstance();
    final l = List<String>.of(p.getStringList(_k) ?? const []);
    l.remove(tg);
    await p.setStringList(_k, l);
  }
}

/// Настройки приложения (размер текста).
class AppSettings {
  static final textScale = ValueNotifier<double>(1.0);

  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    textScale.value = p.getDouble('text_scale') ?? 1.0;
  }

  static Future<void> setTextScale(double v) async {
    textScale.value = v;
    final p = await SharedPreferences.getInstance();
    await p.setDouble('text_scale', v);
  }
}

String defaultNameFor(String tg) {
  final m = RegExp(r'^ember_test_(\d+)$').firstMatch(tg);
  return m != null ? 'Тест ${m.group(1)}' : tg;
}

/// Если публичного имени ещё нет — ставим имя по умолчанию и занимаем его в реестре.
Future<void> ensureUsername(String uid, String tg, String? current) async {
  if (current != null && current.isNotEmpty) return;
  final db = FirebaseFirestore.instance;
  try {
    await db.collection('users').doc(uid).set({'username': tg}, SetOptions(merge: true));
    await db.collection('usernames').doc(tg).set({'tg': tg});
  } catch (_) {}
}

/// Вход в аккаунт. Каждый вход — новая anonymous-сессия, профиль переносится из прошлой.
Future<void> enterAccount(String tg) async {
  final db = FirebaseFirestore.instance;
  final auth = FirebaseAuth.instance;
  if (auth.currentUser != null) await auth.signOut();
  final cred = await auth.signInAnonymously();
  final uid = cred.user!.uid;
  final data = <String, dynamic>{
    'tg_username': tg,
    'last_login': FieldValue.serverTimestamp(),
    'display_name': defaultNameFor(tg),
  };
  try {
    final old = await db.collection('users').where('tg_username', isEqualTo: tg).get();
    final prev = latestUserDoc(old.docs.where((d) => d.id != uid));
    if (prev != null) {
      final p = prev.data();
      for (final k in const ['display_name', 'photo_url', 'bio', 'username']) {
        if (p[k] != null) data[k] = p[k];
      }
    }
  } catch (_) {}
  await db.collection('users').doc(uid).set(data, SetOptions(merge: true));
  await ensureUsername(uid, tg, data['username'] as String?);
}

/// Переключение на другой сохранённый аккаунт.
Future<void> switchAccount(BuildContext context, String tg) async {
  final nav = Navigator.of(context, rootNavigator: true);
  final sm = ScaffoldMessenger.of(context);
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (_) => const PopScope(canPop: false, child: Center(child: CircularProgressIndicator())),
  );
  try {
    await enterAccount(tg);
  } catch (e) {
    try {
      await FirebaseAuth.instance.signOut();
    } catch (_) {}
    sm.showSnackBar(SnackBar(content: Text('Не удалось переключиться: $e')));
  }
  nav.popUntil((r) => r.isFirst);
}

Future<void> _changeUsername(String uid, String tg, String current, String next) async {
  final db = FirebaseFirestore.instance;
  await db.runTransaction((tx) async {
    final newRef = db.collection('usernames').doc(next);
    final oldRef = db.collection('usernames').doc(current);
    final newSnap = await tx.get(newRef);
    final oldSnap = (current.isNotEmpty && current != next) ? await tx.get(oldRef) : null;
    if (newSnap.exists && newSnap.data()?['tg'] != tg) throw 'taken';
    tx.set(newRef, {'tg': tg});
    if (oldSnap != null && oldSnap.exists && oldSnap.data()?['tg'] == tg) tx.delete(oldRef);
    tx.update(db.collection('users').doc(uid), {'username': next});
  });
}

void showUsernameDialog(BuildContext context, {required String uid, required String tg, required String current}) {
  final ctrl = TextEditingController(text: current);
  String? error;
  var busy = false;
  showDialog(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        title: const Text('Имя пользователя'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextField(
            controller: ctrl,
            autofocus: true,
            autocorrect: false,
            decoration: InputDecoration(prefixText: '@', errorText: error),
          ),
          const SizedBox(height: 10),
          const Text(
            '5–32 символа: латинские буквы, цифры и _. Начинается с буквы. По этому имени вас находят в поиске.',
            style: TextStyle(color: Colors.grey, fontSize: 12),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ОТМЕНА')),
          TextButton(
            onPressed: busy
                ? null
                : () async {
                    final v = ctrl.text.trim().toLowerCase().replaceFirst(RegExp(r'^@+'), '');
                    if (!RegExp(r'^[a-z][a-z0-9_]{4,31}$').hasMatch(v)) {
                      setS(() => error = 'Неверный формат');
                      return;
                    }
                    if (v == current) {
                      Navigator.pop(ctx);
                      return;
                    }
                    setS(() {
                      busy = true;
                      error = null;
                    });
                    try {
                      await _changeUsername(uid, tg, current, v);
                      if (ctx.mounted) Navigator.pop(ctx);
                    } catch (e) {
                      setS(() {
                        busy = false;
                        error = e == 'taken' ? 'Это имя уже занято' : 'Ошибка: $e';
                      });
                    }
                  },
            child: const Text('СОХРАНИТЬ'),
          ),
        ],
      ),
    ),
  );
}
