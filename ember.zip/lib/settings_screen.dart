import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'accounts.dart';
import 'auth_screens.dart';
import 'config.dart';
import 'profile_screen.dart';
import 'widgets.dart';

class SettingsTab extends StatefulWidget {
  final Map<String, dynamic> me;
  const SettingsTab({super.key, required this.me});
  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  List<SavedAccount> _accounts = [];

  String get myTg => widget.me['tg_username'] as String;
  SavedAccount get _current => currentSaved(widget.me);

  @override
  void initState() {
    super.initState();
    _loadAccounts();
  }

  Future<void> _loadAccounts() async {
    await AccountStore.add(_current);
    final l = await AccountStore.load();
    if (mounted) setState(() => _accounts = l);
  }

  String get _uid => FirebaseAuth.instance.currentUser!.uid;

  Widget _card(List<Widget> children) => Material(
        color: bubbleOther,
        borderRadius: BorderRadius.circular(16),
        clipBehavior: Clip.antiAlias,
        child: Column(children: children),
      );

  Widget _label(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
        child: Text(t, style: const TextStyle(color: Colors.grey, fontSize: 13)),
      );

  Widget _item(IconData icon, String title, {String? subtitle, VoidCallback? onTap, Color? color}) => ListTile(
        leading: Icon(icon, color: color ?? Colors.white70),
        title: Text(title, style: TextStyle(color: color)),
        subtitle: subtitle == null ? null : Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 12)),
        trailing: (color == null && onTap != null) ? const Icon(Icons.chevron_right, color: Colors.grey) : null,
        onTap: onTap,
      );

  String get _sizeName {
    final v = AppSettings.textScale.value;
    if (v < 0.95) return 'Мелкий';
    if (v > 1.05) return 'Крупный';
    return 'Обычный';
  }

  void _textSize() {
    showDialog(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('Размер текста'),
        children: [
          for (final o in const [('Мелкий', 0.9), ('Обычный', 1.0), ('Крупный', 1.15)])
            SimpleDialogOption(
              onPressed: () {
                AppSettings.setTextScale(o.$2);
                Navigator.pop(ctx);
                setState(() {});
              },
              child: Text(o.$1, style: TextStyle(fontSize: 16, fontWeight: AppSettings.textScale.value == o.$2 ? FontWeight.bold : FontWeight.normal)),
            ),
        ],
      ),
    );
  }

  void _removeAccount(SavedAccount a) {
    final label = a.kind == 't' ? defaultNameFor(a.id) : a.id;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Убрать аккаунт?'),
        content: Text('Аккаунт $label будет убран с этого устройства. Войти в него можно будет снова по логину или почте и паролю.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ОТМЕНА')),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              await AccountStore.remove(a);
              await _loadAccounts();
            },
            child: const Text('УБРАТЬ', style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Выйти из аккаунта?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('ОТМЕНА')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ВЫЙТИ', style: TextStyle(color: Colors.redAccent))),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final cur = _current;
    final before = FirebaseAuth.instance.currentUser?.uid;
    final rest = (await AccountStore.load()).where((a) => !a.sameAs(cur)).toList();
    if (!mounted) return;
    if (rest.isNotEmpty) {
      await switchAccount(context, rest.first);
      if (FirebaseAuth.instance.currentUser?.uid != before) await AccountStore.remove(cur);
      return;
    }
    await AccountStore.remove(cur);
    if (!mounted) return;
    Navigator.of(context).popUntil((r) => r.isFirst);
    await FirebaseAuth.instance.signOut();
  }

  @override
  Widget build(BuildContext context) {
    final me = widget.me;
    final name = (me['display_name'] as String?) ?? '';
    final un = uname(me);
    final user = FirebaseAuth.instance.currentUser;
    final email = isPasswordUser(user) ? user?.email : null;
    return ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), children: [
      InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileScreen(uid: _uid, isMe: true))),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(children: [
            UserAvatar(url: me['photo_url'] as String?, name: name, radius: 56),
            const SizedBox(height: 12),
            Text(name, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 2),
            Text('@$un', style: const TextStyle(fontSize: 16, color: accent)),
          ]),
        ),
      ),
      _card([
        _item(Icons.person_outline, 'Профиль', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileScreen(uid: _uid, isMe: true)))),
        _item(Icons.alternate_email, 'Имя пользователя', subtitle: '@$un', onTap: () => showUsernameDialog(context, uid: _uid, tg: myTg, current: un)),
        if (email != null) _item(Icons.mail_outline, 'Почта', subtitle: email),
      ]),
      _label('АККАУНТЫ НА УСТРОЙСТВЕ (${_accounts.length}/${AccountStore.maxAccounts})'),
      _card([
        for (final a in _accounts)
          _AccountTile(
            account: a,
            current: a.sameAs(_current),
            onTap: () => switchAccount(context, a),
            onLongPress: () {
              if (a.sameAs(_current)) {
                snack(context, 'Чтобы убрать текущий аккаунт, нажмите «Выйти»');
              } else {
                _removeAccount(a);
              }
            },
          ),
        if (_accounts.length < AccountStore.maxAccounts)
          _item(Icons.person_add_alt_1_outlined, 'Добавить аккаунт',
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen(addMode: true)))),
      ]),
      const SizedBox(height: 16),
      _card([
        _item(Icons.notifications_none, 'Уведомления и звук', subtitle: 'Скоро', onTap: () => snack(context, 'Скоро')),
        _item(Icons.chat_bubble_outline, 'Сообщения', subtitle: 'Размер текста: $_sizeName', onTap: _textSize),
        _item(Icons.lock_outline, 'Безопасность', subtitle: 'Скоро', onTap: () => snack(context, 'Скоро')),
      ]),
      const SizedBox(height: 16),
      _card([
        _item(Icons.logout, 'Выйти', color: Colors.redAccent, onTap: _logout),
      ]),
    ]);
  }
}

class _AccountTile extends StatelessWidget {
  final SavedAccount account;
  final bool current;
  final VoidCallback onTap, onLongPress;
  const _AccountTile({required this.account, required this.current, required this.onTap, required this.onLongPress});

  Widget _tile(String name, String? photo, String un) => ListTile(
        leading: UserAvatar(url: photo, name: name, radius: 22),
        title: Text(name),
        subtitle: Text('@$un', style: const TextStyle(color: Colors.grey, fontSize: 12)),
        trailing: current ? const Icon(Icons.check_circle, color: accent) : null,
        onTap: current ? null : onTap,
        onLongPress: onLongPress,
      );

  @override
  Widget build(BuildContext context) {
    final db = FirebaseFirestore.instance;
    if (account.kind == 'e') {
      return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: db.collection('users').doc(account.uid).snapshots(),
        builder: (context, s) {
          final d = s.data?.data();
          return _tile(
            (d?['display_name'] as String?) ?? account.id,
            d?['photo_url'] as String?,
            d == null ? account.id : uname(d),
          );
        },
      );
    }
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: db.collection('users').where('tg_username', isEqualTo: account.id).snapshots(),
      builder: (context, snap) {
        var name = defaultNameFor(account.id);
        String? photo;
        var un = account.id;
        final u = snap.hasData ? latestUserDoc(snap.data!.docs) : null;
        if (u != null) {
          final d = u.data();
          name = (d['display_name'] as String?) ?? name;
          photo = d['photo_url'] as String?;
          un = uname(d);
        }
        return _tile(name, photo, un);
      },
    );
  }
}
