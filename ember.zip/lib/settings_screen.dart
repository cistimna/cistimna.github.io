import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'accounts.dart';
import 'auth_screens.dart';
import 'config.dart';
import 'profile_screen.dart';
import 'widgets.dart';

class SettingsTab extends StatefulWidget {
  final Map<String, dynamic> me;
  const SettingsTab({super.key, required this.me});
  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  List<String> _accounts = [];

  String get myTg => widget.me['tg_username'] as String;

  @override
  void initState() {
    super.initState();
    _loadAccounts();
  }

  Future<void> _loadAccounts() async {
    await AccountStore.add(myTg);
    final l = await AccountStore.load();
    if (mounted) setState(() => _accounts = l);
  }

  String get _uid => FirebaseAuth.instance.currentUser!.uid;

  Widget _card(List<Widget> children) => Material(
        color: bubbleOther,
        borderRadius: BorderRadius.circular(16),
        clipBehavior: Clip.antiAlias,
        child: Column(children: children),
      );

  Widget _label(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
        child: Text(t, style: const TextStyle(color: Colors.grey, fontSize: 13)),
      );

  Widget _item(IconData icon, String title, {String? subtitle, VoidCallback? onTap, Color? color}) => ListTile(
        leading: Icon(icon, color: color ?? Colors.white70),
        title: Text(title, style: TextStyle(color: color)),
        subtitle: subtitle == null ? null : Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 12)),
        trailing: color == null ? const Icon(Icons.chevron_right, color: Colors.grey) : null,
        onTap: onTap,
      );

  String get _sizeName {
    final v = AppSettings.textScale.value;
    if (v < 0.95) return 'Мелкий';
    if (v > 1.05) return 'Крупный';
    return 'Обычный';
  }

  void _textSize() {
    showDialog(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('Размер текста'),
        children: [
          for (final o in const [('Мелкий', 0.9), ('Обычный', 1.0), ('Крупный', 1.15)])
            SimpleDialogOption(
              onPressed: () {
                AppSettings.setTextScale(o.$2);
                Navigator.pop(ctx);
                setState(() {});
              },
              child: Text(o.$1, style: TextStyle(fontSize: 16, fontWeight: AppSettings.textScale.value == o.$2 ? FontWeight.bold : FontWeight.normal)),
            ),
        ],
      ),
    );
  }

  void _removeAccount(String tg) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Убрать аккаунт?'),
        content: Text('Аккаунт ${defaultNameFor(tg)} будет убран с этого устройства. Войти в него можно будет снова по логину и паролю.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ОТМЕНА')),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              await AccountStore.remove(tg);
              await _loadAccounts();
            },
            child: const Text('УБРАТЬ', style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Выйти из аккаунта?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('ОТМЕНА')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ВЫЙТИ', style: TextStyle(color: Colors.redAccent))),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await AccountStore.remove(myTg);
    final rest = await AccountStore.load();
    if (!mounted) return;
    if (rest.isNotEmpty) {
      await switchAccount(context, rest.first);
      return;
    }
    Navigator.of(context).popUntil((r) => r.isFirst);
    await FirebaseAuth.instance.signOut();
  }

  @override
  Widget build(BuildContext context) {
    final me = widget.me;
    final name = (me['display_name'] as String?) ?? '';
    final un = uname(me);
    return ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), children: [
      InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileScreen(uid: _uid, isMe: true))),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(children: [
            UserAvatar(url: me['photo_url'] as String?, name: name, radius: 56),
            const SizedBox(height: 12),
            Text(name, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 2),
            Text('@$un', style: const TextStyle(fontSize: 16, color: accent)),
          ]),
        ),
      ),
      _card([
        _item(Icons.person_outline, 'Профиль', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileScreen(uid: _uid, isMe: true)))),
        _item(Icons.alternate_email, 'Имя пользователя', subtitle: '@$un', onTap: () => showUsernameDialog(context, uid: _uid, tg: myTg, current: un)),
      ]),
      _label('АККАУНТЫ НА УСТРОЙСТВЕ (${_accounts.length}/${AccountStore.maxAccounts})'),
      _card([
        for (final tg in _accounts)
          _AccountTile(
            tg: tg,
            current: tg == myTg,
            onTap: () => switchAccount(context, tg),
            onLongPress: () {
              if (tg == myTg) {
                snack(context, 'Чтобы убрать текущий аккаунт, нажмите «Выйти»');
              } else {
                _removeAccount(tg);
              }
            },
          ),
        if (_accounts.length < AccountStore.maxAccounts)
          _item(Icons.person_add_alt_1_outlined, 'Добавить аккаунт',
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen(addMode: true)))),
      ]),
      const SizedBox(height: 16),
      _card([
        _item(Icons.notifications_none, 'Уведомления и звук', subtitle: 'Скоро', onTap: () => snack(context, 'Скоро')),
        _item(Icons.chat_bubble_outline, 'Сообщения', subtitle: 'Размер текста: $_sizeName', onTap: _textSize),
        _item(Icons.lock_outline, 'Безопасность', subtitle: 'Скоро', onTap: () => snack(context, 'Скоро')),
      ]),
      const SizedBox(height: 16),
      _card([
        _item(Icons.logout, 'Выйти', color: Colors.redAccent, onTap: _logout),
      ]),
    ]);
  }
}

class _AccountTile extends StatelessWidget {
  final String tg;
  final bool current;
  final VoidCallback onTap, onLongPress;
  const _AccountTile({required this.tg, required this.current, required this.onTap, required this.onLongPress});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').where('tg_username', isEqualTo: tg).snapshots(),
      builder: (context, snap) {
        var name = defaultNameFor(tg);
        String? photo;
        var un = tg;
        final u = snap.hasData ? latestUserDoc(snap.data!.docs) : null;
        if (u != null) {
          final d = u.data();
          name = (d['display_name'] as String?) ?? name;
          photo = d['photo_url'] as String?;
          un = uname(d);
        }
        return ListTile(
          leading: UserAvatar(url: photo, name: name, radius: 22),
          title: Text(name),
          subtitle: Text('@$un', style: const TextStyle(color: Colors.grey, fontSize: 12)),
          trailing: current ? const Icon(Icons.check_circle, color: accent) : null,
          onTap: current ? null : onTap,
          onLongPress: onLongPress,
        );
      },
    );
  }
}
