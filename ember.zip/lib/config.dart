import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

/// Адрес сервера на Raspberry Pi (работает только в вашей Wi-Fi сети).
const String backendUrl = 'http://192.168.0.199:8080';

const firebaseOptions = FirebaseOptions(
  apiKey: 'AIzaSyAEhuuXdFlr_9NPY65UP9wirBIaNBMCHYQ',
  authDomain: 'corenet-bc040.firebaseapp.com',
  databaseURL: 'https://corenet-bc040-default-rtdb.firebaseio.com',
  projectId: 'corenet-bc040',
  storageBucket: 'corenet-bc040.firebasestorage.app',
  messagingSenderId: '869463469864',
  appId: '1:869463469864:web:d16b3c71cc38e80eedea1d',
);

const emberOrange = Color(0xFFFF6A1F);
const bgDark = Color(0xFF14100E);
const surfaceDark = Color(0xFF1E1816);
const bubbleMe = Color(0xFF5A2A12);
const bubbleOther = Color(0xFF261E1B);
