import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

/// Адрес сервера на Raspberry Pi (работает только в вашей Wi-Fi сети).
const String backendUrl = 'http://192.168.0.199:8080';

const firebaseOptions = FirebaseOptions(
  apiKey: 'AIzaSyAEhuuXdFlr_9NPY65UP9wirBIaNBMCHYQ',
  authDomain: 'corenet-bc040.firebaseapp.com',
  databaseURL: 'https://corenet-bc040-default-rtdb.firebaseio.com',
  projectId: 'corenet-bc040',
  storageBucket: 'corenet-bc040.firebasestorage.app',
  messagingSenderId: '869463469864',
  appId: '1:869463469864:web:d16b3c71cc38e80eedea1d',
);

const accent = Color(0xFF2F6BFF);
const bgDark = Color(0xFF05070F);
const surfaceDark = Color(0xFF0B1020);
const bubbleMe = Color(0xFF12306E);
const bubbleOther = Color(0xFF111827);
const plaqueBlue = Color(0xFF062E94);

// Тестовые аккаунты: здесь только соль и хэши, сами логины и пароли в коде не хранятся.
const _salt = 'e0d562d9340e7d74e9e0401d99a47f06';
const _testHashes = [
  '4b9a2e218a9c23d4618f080fd522f302f0bba5d620d07909d0819b7412cf3ccb',
  'bccdf864d65913cb92fd622848864630e97ffde316cc1c207f6b0e9b357735d4',
  'be8eaf4177895bf933318dd309e41c33d927ca91504abf53b03142174b8ae84a',
];

/// Возвращает номер тестового аккаунта (0..2) или -1, если логин/пароль не подошли.
int testAccountIndex(String login, String password) {
  final h = sha256.convert(utf8.encode('$_salt|${login.trim().toLowerCase()}|$password')).toString();
  return _testHashes.indexOf(h);
}
